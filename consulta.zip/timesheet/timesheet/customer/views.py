from django.shortcuts import render, redirect, get_object_or_404
from django.core.urlresolvers import reverse_lazy
from .models import Customer
from context.models import Context
from .forms import CustomerForm
from django.http import HttpResponse
from django.views.generic.edit import UpdateView, DeleteView
# Create your views here.

def index(request):
    customers = Customer.objects.filter(context__person=request.user.person)
    context = {
        'customers' : customers
    }
    return render(request, 'customer/list.html', context)

def createCustomer(request):

    if request.method == 'POST':
        form = CustomerForm(request, request.POST)
        if form.is_valid():
            custumer = form.save(commit=False)
            custumer.creator = request.user.person
            custumer.save()
            return redirect('customer:home')
        else:
            return render(request, 'customer/form.html',  {'form' : form})
    else:
         form = CustomerForm(request)
    context = {
        'form' : form
    }
    return render(request, 'customer/form.html', context)

def updateCustomer(request, pk):
    custumer = get_object_or_404(Customer, pk=pk)
    if request.method == "POST":
        form = CustomerForm(request, request.POST, instance=custumer)
        if form.is_valid():
            form.save()
            return redirect('customer:home')
        else:
            return render(request, 'customer/form.html', {'form' : form })
    else:
        form = CustomerForm(request, instance=custumer)
        return render(request, 'customer/form.html', {'form' : form })

class DeleteCustomer(DeleteView):
    model = Customer
    success_url = reverse_lazy('customer:home')
    template_name = 'confirmdelete.html'