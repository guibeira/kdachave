from django.apps import AppConfig


class CustumerConfig(AppConfig):
    name = 'customer'
