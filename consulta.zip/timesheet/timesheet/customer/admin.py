from django.contrib import admin
from .models import Customer
# Register your models here.


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
     list_display = ('name', 'iscompany', 'creator')
     list_filter = ('name', 'iscompany')
     search_fields = ['name']


# admin.site.register(Customer, CustomerAdmin)
