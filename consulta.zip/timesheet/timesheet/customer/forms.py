from django import forms
from .models import Customer
from context.models import Context

class CustomerForm(forms.ModelForm):

    def __init__(self, request, *args, **kwargs):
        super(CustomerForm, self).__init__(*args, **kwargs)
        if request.user:
            send = []
            for context in Context.objects.filter(person=request.user.person):
                send.append((context.pk, context))
            self.fields['context'].choices = send

    class Meta:
        model = Customer
        fields = ['name', 'iscompany', 'user', 'context']