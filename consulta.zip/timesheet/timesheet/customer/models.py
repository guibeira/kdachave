from django.db import models
from django.utils.translation import ugettext_lazy as _
# Create your models here.


class Customer(models.Model):
    name = models.CharField(max_length=100)
    iscompany = models.BooleanField(_('é compania'))
    creator = models.ForeignKey('person.Person')
    user = models.ForeignKey('auth.User', null=True, blank=True)
    context = models.ForeignKey('context.Context', null=True)


    def __str__(self):
        return self.name

def getCustumersbyContext(contexts):

    toreturn= []
    for context in contexts:
        custumers = list(Customer.objects.filter(context=context))
        return custumers

