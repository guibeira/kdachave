from django.conf.urls import url
from .import views

urlpatterns = [

    url(r'^/$', views.index, name='home'),
    url(r'^/create/$', views.createCustomer, name='create'),
    url(r'^/update/(?P<pk>[0-9]+)/$', views.updateCustomer, name='update'),
    url(r'^/delete/(?P<pk>[0-9]+)/$', views.DeleteCustomer.as_view(), name='delete'),
]
