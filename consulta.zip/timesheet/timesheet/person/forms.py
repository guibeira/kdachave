from django import forms
from django.contrib.auth.models import User , Group
from .models import Person

class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta:
        model = User
        fields = ('username', 'password', 'groups', 'user_permissions', 'is_active')
        widgets = {'user_permissions': forms.CheckboxSelectMultiple(),}


class UserFormUpdate(forms.ModelForm):

    class Meta:
        model = User
        fields = ('username', 'groups', 'user_permissions', 'is_active')
        widgets = {'user_permissions': forms.CheckboxSelectMultiple(),}

class PersonForm(forms.ModelForm):
    class Meta:
        model = Person
        fields = ('name',)

class GroupForm(forms.ModelForm):

    class Meta:
        model = Group
        fields = ('name', 'permissions',)
        widgets = {'permissions': forms.CheckboxSelectMultiple(),}
