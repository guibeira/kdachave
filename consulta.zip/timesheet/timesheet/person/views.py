from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required, permission_required
# Forms
from .forms import PersonForm, UserForm, GroupForm, UserFormUpdate
# Models
from person.models import Person
from box.models import Box
from case.models import Case
from proxy.models import Proxy
from django.contrib.auth.models import Group, User
# Generics
from django.views.generic.edit import DeleteView
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from datetime import datetime, timezone

now = datetime.now(timezone.utc)


def searchpersoninproxy(request):
    if request.method == 'POST':
        typee = request.POST.get('type')
        typeid = request.POST.get('id')
        searchPersonContent = request.POST.get('searchPersonContent').lower()

        listpersons = []

        if(typee == "box"):
            box = get_object_or_404(Box, pk=typeid)
            proxies = Proxy.objects.filter(box=box)
            for proxy in proxies:
                for p in proxy.person.all():
                    personname = str(p.name).lower()
                    if searchPersonContent in personname:
                        if(p not in listpersons):
                            d = {p: [proxy.startDate, proxy.endDate, proxy.pk]}
                            listpersons.append(d)

            context = {
        		'box' : box,
                'listpersons':listpersons,
                'now' : now,
            }
            return render(request, 'person/resultsearchpersoninproxybox.html', context)

        elif(typee == "case"):
            case = get_object_or_404(Case, pk=typeid)
            proxies = Proxy.objects.filter(case=case)
            for proxy in proxies:
                for p in proxy.person.all():
                    personname = str(p.name).lower()
                    if searchPersonContent in personname:
                        if(p not in listpersons):
                            d = {p:[proxy.startDate, proxy.endDate, proxy.pk]}
                            listpersons.append(d)

            context = {
        		'case' : case,
                'listpersons':listpersons,
                'now' : now,
            }
            return render(request, 'person/resultsearchpersoninproxycase.html', context)


@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect('home')
    else:
        form = PasswordChangeForm(request.user)
    data = {
        'form': form
    }
    return render(request, "person/reset-password.html", data)


class DeleteGroup(DeleteView):
    model = Group
    success_url = reverse_lazy('person:listgroups')
    template_name = 'person/confirmdelete.html'


@permission_required('person.change_person', login_url='/login/')
def update_person(request,  id):
    user = get_object_or_404(User, pk=id)

    if request.method == 'POST':
        user_form = UserFormUpdate(request.POST, instance=user)
        person_form = PersonForm(request.POST, instance=user.person)
        if user_form.is_valid() and person_form.is_valid():
            user_form.save()
            person_form.save()
            return redirect('person:listpersons')
    else:
        user_form = UserFormUpdate(instance=user)
        person_form = PersonForm(instance=user.person)
    return render(request, 'person/person.html', {
        'user_form': user_form,
        'person_form': person_form
    })


@permission_required('person.add_person', login_url='/login/')
def create(request):
        if request.method == 'POST':
            user_form = UserForm(request.POST)
            person_form = PersonForm(request.POST)

            if user_form.is_valid() and person_form.is_valid():
                password = user_form.cleaned_data['password']
                user = user_form.save()
                p1 = person_form.save()
                user.set_password(password)
                user.save()
                p1.creator = request.user
                p1.user = user
                p1.save()
                # Box.objects.create(name='Initial', owner= p1)

                return redirect('person:listpersons')

            else:
                return render(request, 'person/person.html', {
                    'user_form': user_form,
                    'person_form': person_form
                })

        else:
            user_form = UserForm()
            person_form = PersonForm()
        return render(request, 'person/person.html', {
            'user_form': user_form,
            'person_form': person_form
        })


def creteGroups(request):

    if request.method == "POST":
        form = GroupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('person:listgroups')
        else:
            return render(request, 'person/groups.html', {
                'form': form,
            })
    else:
        form = GroupForm()
    return render(request, 'person/groups.html', {
        'form': form,

    })


def listGroups(request):
    groups = Group.objects.all()
    return render(request, 'person/groupstable.html', {
        'groups': groups,

    })


def listPersons(request):
    persons = Person.objects.all()
    return render(request, 'person/listpersons.html', {
        'persons': persons,

    })


def editGroup(request, id):
    group = get_object_or_404(Group, pk=id)
    if request.method == "POST":
        form = GroupForm(request.POST, instance=group)
        if form.is_valid():
            form.save()
            return redirect('person:listgroups')
    else:

        group = get_object_or_404(Group, pk=id)
        form = GroupForm(instance=group)

    return render(request, 'person/groups.html', {
        'form': form,

    })
