from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^/update/(?P<id>[0-9]+)/$', views.update_person, name='update'),
    url(r'^/create$', views.create, name='create'),
    url(r'^/password-reset$', views.change_password, name='password_change'),
    url(r'^/creategroup$', views.creteGroups, name='creategroup'),
    url(r'^/listgroups$', views.listGroups, name='listgroups'),
    url(r'^/listpersons$', views.listPersons, name='listpersons'),
    url(r'^/editgroup/(?P<id>[0-9]+)/$', views.editGroup, name='editgroup'),
    url(r'^/deletegroup/(?P<pk>[0-9]+)/$', views.DeleteGroup.as_view(), name='deletegroup'),
    url(r'^/searchpersoninproxy$', views.searchpersoninproxy, name='searchpersoninproxy'),


]
