from django.db import models
# Create your models here.


class Person(models.Model):
    name = models.CharField(max_length=200)
    user = models.OneToOneField('auth.User', null=True, blank=True)
    creator = models.ForeignKey('auth.User', related_name='creator', null=True, blank=True)
    creationDate = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
