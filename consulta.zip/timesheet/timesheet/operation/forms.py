from django import forms
from .models import Operation
from invoice.models import Invoice, Installment
from bank.models import getbankbycontext


class OperationDebitForm(forms.ModelForm):

    invoice = forms.ModelChoiceField(
        queryset=Invoice.objects.filter(modality='debit').filter(paid=False),
        widget=forms.Select(), 
    )
    def __init__(self, request, *args, **kwargs):
        super(OperationDebitForm, self).__init__(*args, **kwargs)
        if request.user:
            send = []
            for bank in getbankbycontext(request.user):
                send.append((bank.pk, bank))
            self.fields['bank'].choices = send
     

    class Meta:
        model = Operation
        fields = ('invoice', 'operationstatus', 'bank')

class OperationCreditForm(forms.ModelForm):

    invoice = forms.ModelChoiceField(
        queryset=Invoice.objects.filter(modality='credit').filter(paid=False),
        widget=forms.Select(), 
    )
    def __init__(self, request, *args, **kwargs):
        super(OperationCreditForm, self).__init__(*args, **kwargs)
        if request.user:
            send = []
            for bank in getbankbycontext(request.user):
                send.append((bank.pk, bank))
            self.fields['bank'].choices = send

    class Meta:
        model = Operation
        fields = ('invoice', 'operationstatus', 'bank')
