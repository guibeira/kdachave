from django.db import models
from djmoney.models.fields import MoneyField
from django.db.models import Count
# Create your models here.

class Operation(models.Model):

    correntvalue = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    operationvalue =  MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    operationresult = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    bank = models.ForeignKey('bank.Bank', null=True)
    invoice  = models.ForeignKey('invoice.Invoice', null=True)
    operationstatus = models.ForeignKey('OperationStatus', null=True)
    date = models.DateTimeField(auto_now_add=True, null=True)
    
    def __str__(self):
        return '{} {}'.format(self.invoice,self.operationstatus)


class OperationStatus(models.Model):

    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name


def getbalance(bank):
    operations = Operation.objects.filter(bank=bank).latest('date')
    return operations

