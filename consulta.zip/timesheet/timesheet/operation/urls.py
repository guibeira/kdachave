from django.conf.urls import url
from .import views

urlpatterns = [

    url(r'^/$', views.index, name='home'),
    url(r'^/debit/$', views.debit, name='debit'),
    url(r'^/credit/$', views.credit, name='credit'),
    url(r'^/extract/(?P<pk>[0-9]+)/$', views.extract, name='extract'),
    url(r'^/account/(?P<pk>[0-9]+)/$', views.accountdetails, name='account'),
    url(r'^/casedatails/(?P<pk>[0-9]+)/$', views.casedatails, name='casedatails'),
    url(r'^/bankcustumer/(?P<pk>[0-9]+)/$', views.bankcustumer, name='extractcustumer'),
    url(r'^/bankcustumerdetail/(?P<pk>[0-9]+)/$', views.bankcustumerdetail, name='bankcustumerdetail')

    
]
