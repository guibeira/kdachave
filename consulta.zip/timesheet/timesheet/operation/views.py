from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, JsonResponse
from .forms import OperationDebitForm, OperationCreditForm
from django.http import Http404
from .models import getbalance, Operation 
from case.models import getAllCasesbyUser, Case
from bank.models import Bank, getbankbycontext
from customer.models import getCustumersbyContext, Customer
from context.models import Context
from expense.models import getTotalExpensebyBanks, getExpensebyBanks
from work.models import getTotalworksgroup, getTotalworksgroup, getTotalHourbyCase, getAverageHoursbyCase, getTotalHoursbyCase, Work
from box.models import callpersonsofuser
from datetime import datetime


def debit(request):

    if request.is_ajax():
        if request.method == "GET":
            form = OperationDebitForm(request)
            return render(request, 'operation/modal_form.html', {'form':form })
        if request.method == "POST":
            form = OperationDebitForm(request, request.POST)
            if form.is_valid():
                operation = form.save(commit=False)
                # operation.save()
                invoice = operation.invoice
                invoice = operation.invoice
                invoice.datepaid = datetime.now()
                invoice.paid = True
                invoice.save()
                # operation.bank = invoice.receiver
                lastoperation = getbalance(operation.bank)
                if lastoperation.operationresult is None:
                    lastoperation.operationresult = 0

                operation.correntvalue = lastoperation.operationresult
                operation.operationvalue = -invoice.amount
                total = lastoperation.operationresult - invoice.amount
                operation.operationresult = total
                operation.save()
                        
                lastoperationRecipient = getbalance(invoice.recipient)
                if lastoperationRecipient.operationresult is None:
                    lastoperationRecipient.operationresult = 0
                correntvalue = lastoperationRecipient.operationresult
                operationvalue = invoice.amount
                operationresult = lastoperationRecipient.operationresult + invoice.amount
                Operation.objects.create(correntvalue=correntvalue, operationvalue=operationvalue, operationresult=operationresult, bank=invoice.recipient, invoice=operation.invoice, operationstatus=operation.operationstatus )
                
                return HttpResponse(status=200)
            else:
                print(form.errors)
                raise Http404
    else:
        raise Http404

def credit(request):

    if request.is_ajax():
        if request.method == "GET":
            form = OperationCreditForm(request)
            return render(request, 'operation/modal_form.html', {'form':form })
        if request.method == "POST":
            form = OperationCreditForm(request, request.POST)
            if form.is_valid():
                #save the operation
                operation = form.save(commit=False)
                invoice = operation.invoice
                invoice = operation.invoice
                invoice.datepaid = datetime.now()
                invoice.paid = True
                invoice.save()
                lastoperation = getbalance(operation.bank)
                if lastoperation.operationresult is None:
                    lastoperation.operationresult = 0

                operation.correntvalue = lastoperation.operationresult
                operation.operationvalue = invoice.amount
          
                if lastoperation.operationresult.amount > 0:
                    total = lastoperation.operationresult - invoice.amount
                else:
                    total = lastoperation.operationresult + invoice.amount
                total = lastoperation.operationresult + invoice.amount
           
                operation.operationresult = total
                operation.save()
                #make the operation for debit account
                        
                lastoperationRecipient = getbalance(invoice.recipient)
                if lastoperationRecipient.operationresult is None:
                    lastoperationRecipient.operationresult = 0
                correntvalue = lastoperationRecipient.operationresult
                operationvalue = -invoice.amount
                operationresult = lastoperationRecipient.operationresult + operationvalue
                Operation.objects.create(correntvalue=correntvalue, operationvalue=operationvalue, operationresult=operationresult, bank=invoice.recipient, invoice=operation.invoice, operationstatus=operation.operationstatus )
               
                return HttpResponse(status=200)
            else:
                print(form.errors)
                raise Http404
    else:
        raise Http404

def index(request):

    totalwork = getTotalworksgroup()
    cases = getAllCasesbyUser(request, request.user)
    personsbyuser = callpersonsofuser(request)
    contexts = list(Context.objects.filter(person=request.user.person))
    custumers = getCustumersbyContext(contexts)
   
    # averages = getAverageHours(personsbyuser)
    # totalhoursbyuser = getTotalHoursbyCase(personsbyuser)
    accounts = getbankbycontext(request.user)
    context = {
        'cases': cases, 
        'accounts' : accounts,
        'custumers' :custumers
    }
    
    return render(request, 'operation/index.html',context)

def accountdetails(request, pk):

    bank = get_object_or_404(Bank, pk=pk)
    accounts = list(getbankbycontext(request.user))
    if bank in accounts:
        balance = getbalance(bank)
        personsbyuser = callpersonsofuser(request)
        operations = Operation.objects.filter(bank=bank).order_by('-date')
        totalwork = getTotalworksgroup()
        operationlastfive = Operation.objects.filter(bank=bank).order_by('-date')[:5]
        banks = [bank]
        expensestotal = getTotalExpensebyBanks(banks)
        expenses = getExpensebyBanks(bank)
        constext = {
            'operationlastfives' : operationlastfive,
            'balance' : balance,
            'operations': operations,
            'expenses' : expenses,
            'totalexpenses' : expensestotal[0][1]     
        }
        return render(request, 'operation/selected_account.html', constext)
    else:
        return HttpResponse(status=500)

def extract(request, pk):
    if request.is_ajax:
        if request.method == "POST":
            bank = get_object_or_404(Bank, pk=pk)
            accounts = list(getbankbycontext(request.user))
            if bank in accounts:
                operations = Operation.objects.filter(bank=bank).order_by('-date')
                context = {
                    'operations' :operations
                }
                return render(request, 'operation/extracttable.html', context)
            else:
                raise Http404
        else:
            raise Http404
    else:
        raise Http404

def casedatails(request, pk):
    case = get_object_or_404(Case, pk=pk)
    works = Work.objects.filter(case=case)
    personsbyuser = callpersonsofuser(request)
    totalhoursbyuser = getTotalHoursbyCase(personsbyuser, case)
    averages = getAverageHoursbyCase(personsbyuser, case)
    totalhours = getTotalHourbyCase(case)
    print(averages)
    context = {
        'works': works ,
        'totalhours': totalhours ,
        'totalhoursbyuser':totalhoursbyuser,
        'averages' : averages
    }
    return render(request, 'operation/detailscase.html', context)

def bankcustumer(request, pk):

    contexts = list(Context.objects.filter(person=request.user.person))
    custumers = getCustumersbyContext(contexts)
    custumer = get_object_or_404(Customer, pk=pk)
    if custumer in custumers:
        accounts = Bank.objects.filter(accountDesignation=custumer)
        context = {
            'accounts' : accounts
        }
        return render(request, 'operation/banks_custumer.html', context)
    else:
        raise Http404

def bankcustumerdetail(request, pk):

     bank = get_object_or_404(Bank, pk=pk)
     operations = Operation.objects.filter(bank=bank).order_by('-date')
     context = {
        'operations' :operations
     }
     return render(request, 'operation/extract_bank_custumer.html', context)
    