from django.contrib import admin
from .models import Operation, OperationStatus

# admin.site.register(Operation)
admin.site.register(OperationStatus)
@admin.register(Operation)
class OperationAdmin(admin.ModelAdmin):
    list_display = ('bank', 'invoice','date')
    list_filter = ('bank', 'invoice', 'operationstatus')
    search_fields = ['bank']