from django.shortcuts import render, get_object_or_404
from django.core.urlresolvers import reverse_lazy
from .forms import ExpenseForm
from django.http import Http404
from .models import Expense
from django.http import HttpResponse, JsonResponse
# from django.views.generic.edit import CreateView, UpdateView, DeleteView


def expenseCreate(request):
    # only for ajax requests
    if request.is_ajax():
        if request.method == 'GET':
            form = ExpenseForm()
        if request.method == 'POST':
            form = ExpenseForm(data=request.POST,  files=request.FILES)
            if form.is_valid():
                expense = form.save(commit=False)
                expense.creator = request.user.person
                expense.save()
                return JsonResponse({'title': expense.title, 'value': str(expense.amount), 'pk': expense.pk })
            else:
                print(form.errors)
        return render(request, 'expense/form.html', { 'form': form })
    else:
        raise Http404

def deletebyajax(request, id):
    if request.is_ajax:
        if request.method == "POST":
            expense = get_object_or_404(Expense, pk=id)
            expense.delete()
            return HttpResponse(200)
    else:
        raise Http404