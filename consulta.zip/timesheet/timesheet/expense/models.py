from django.db import models
from djmoney.models.fields import MoneyField
from django.db.models import Sum, Avg
# Create your models here.

class Expense(models.Model):
    
    title = models.CharField(max_length=100)
    attachment = models.FileField(upload_to='uploads/')
    amount = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    invoice = models.ForeignKey('invoice.Invoice', null=True, blank=True)
    creator = models.ForeignKey('person.Person', related_name='creatoruser')

    def __str__(self):
        return self.title

def getTotalExpensebyBanks(banks):
    
    toreturn = []
    for bank in banks:
        total = Expense.objects.filter(invoice__receiver=bank).aggregate(Sum('amount'))
        toreturn.append((bank,  total['amount__sum']))
    return toreturn


def getExpensebyBanks(bank):

    total = Expense.objects.filter(invoice__receiver=bank)
   
    return total