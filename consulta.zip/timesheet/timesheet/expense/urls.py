from django.conf.urls import url
from . import views

urlpatterns = [
     url(r'^/create/$', views.expenseCreate, name='create'),
     url(r'^/delete/(?P<id>[0-9]+)/$', views.deletebyajax, name='deletebyajax'),
]