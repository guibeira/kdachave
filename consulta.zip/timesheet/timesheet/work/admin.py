from django.contrib import admin
from .models import Work
# Register your models here.
admin.site.register(Work)
