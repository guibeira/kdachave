from django.db import models
import moneyed
from djmoney.models.fields import MoneyField
from django.db.models import Count
from django.shortcuts import get_object_or_404
from person.models import Person
from django.db.models import Sum, Avg
from datetime import timedelta
# Create your models here.


class Work(models.Model):

    description = models.TextField(null=True, blank=True)
    creator = models.ForeignKey('person.Person')
    timespent = models.DurationField(max_length=100, null=True, blank=True)
    pricePerunit = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    quantity = models.PositiveIntegerField(null=True, blank=True)
    tax = models.ForeignKey('tax.Tax', null=True, blank=True)
    creationDate = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.description


def getTotalworksgroup():
    
    result = Work.objects.values('creator').annotate(dcount=Count('creator'))
    allresults = []
    for r in result:
        person = get_object_or_404(Person, pk=r['creator'])
        d={ "person" : person, "total": r['dcount']}
        allresults.append(d)
    return allresults

def getTotalHourbyCase(case):
    total = Work.objects.filter(case=case).aggregate(Sum('timespent'))
    return total['timespent__sum']

def getAverageHoursbyCase(persons, case):
    results = {}
    toreturn = []
    for person in persons:
        average = Work.objects.filter(case=case).filter(creator=person).aggregate(Avg('timespent'))
        if average['timespent__avg'] is None:
            average['timespent__avg'] = timedelta(0,0)
        toreturn.append((person,  average['timespent__avg']))
    return toreturn

def getTotalHoursbyCase(persons, case):
    results = {}
    toreturn = []
    for person in persons:
        total = Work.objects.filter(case=case).filter(creator=person).aggregate(Sum('timespent'))
        if total['timespent__sum'] is None:
            total['timespent__sum'] = timedelta(0,0)
        toreturn.append((person,  total['timespent__sum']))
    return toreturn
        
