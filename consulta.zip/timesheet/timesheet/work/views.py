from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
import operator
# Create your views here.
from .forms import WorkForm
# Models
from .models import Work
from box.models import listBoxesForAjax, converterdicinlist
from tax.models import Tax
from case.models import Case, getAllCasesbyUser

from datetime import datetime, timezone, timedelta
from django.contrib.auth.decorators import permission_required
import pytz
from moneyed import Money, BRL
from case.views import listcase as getcases
now = datetime.now(timezone.utc)
# utc = pytz.UTC
# now = utc.localize(datetime.now())


def searchwork(request):
    idcase = request.POST.get('idcase')
    searchContent = request.POST.get('searchContent')
    works = Work.objects.filter(case__pk__contains=idcase).filter(
        description__contains=searchContent).order_by('-id') | Work.objects.filter(case__pk__contains=idcase).filter(creator__name__contains=searchContent).order_by('-id')

    context = {'works': works,
               'case': idcase}

    return render(request, 'work/resultsearchwork.html', context)


@permission_required('case.show_work')
def listworks(request):

    listboxes = listBoxesForAjax(request.user)
    boxes = converterdicinlist(listboxes, [])
    boxesSearch = list(boxes)
    listcase = getAllCasesbyUser(request, request.user)
    caseSearch = list(listcase)
    seletedBox = None
    seletedCase = None
    seletedWork = None
    end_date = None
    start_date = None
    comparatordate = timedelta(hours=int(10), minutes=int(00), seconds=int(00))
    if request.method == 'POST':
        idbox = request.POST.get('box')
        if idbox is not None and idbox != "":
            idbox = int(idbox)
            cleaning = []
            for i in listcase:
                if idbox == i.box.pk:
                    cleaning.append(i)
            listcase = cleaning
            caseSearch = list(listcase)
            seletedBox = idbox

        idcase = request.POST.get('case')
        if idcase is not None and idcase != "":
            idcase = int(idcase)
            cleaning = []
            for i in listcase:
                if idcase == i.pk:
                    cleaning.append(i)
            listcase = cleaning
            seletedCase = idcase


    listcase.sort(key=operator.attrgetter('lastupadate'))
    listcase.reverse()

    works = []
    for case in listcase:
        for work in case.work.all():
            works.append(work)
    worksSeach = list(works)
    if request.method == 'POST':
        idwork = request.POST.get('work')
        if idwork is not None and idwork != "":
            idwork = int(idwork)
            cleaning = []
            for i in works:
                if idwork == i.pk:
                    cleaning.append(i)

            works = cleaning
            seletedWork = idwork
            hours = works[0].timespent if works[0].timespent is not None else '00:00:00'
            caseParent = Case.objects.get(work=works[0])
            seletedBox = caseParent.box.pk
            casesfiltred = getcases(request, caseParent.box)
            casesfiltred = converterdicinlist(casesfiltred, [])
            worksSeach = []
            for work in caseParent.work.all():
                worksSeach.append(work)
            context = {'boxesSearch': boxesSearch,
                       'caseSearch': casesfiltred,
                       'worksSeach':worksSeach,
                       'case': caseParent,
                       'work': works[0],
                       'hours': hours,
                       'selectedbox': seletedBox,
                       'selectedcase': caseParent.id,
                       'selectedwork': works[0].pk
                       }

            return render(request, 'work/getworksFilter.html', context)

    if request.method == "POST":
        start = request.POST.get('start')
        if(start is not None and start != ''):
            start_date = datetime.strptime(start, '%d/%m/%Y')
            start_date = pytz.utc.localize(start_date)
        end = request.POST.get('end')
        if(end is not None and end != ""):
            end_date = datetime.strptime(end, '%d/%m/%Y')
            end_date = pytz.utc.localize(end_date)

    if start_date is not None and end_date is not None:
        cleaningwork = []
        cleaningcase = []
        for case in listcase:
            for work in case.work.all():
                if work.creationDate is not None:
                    if work.creationDate >= start_date.date() and work.creationDate <= end_date.date():

                        if case not in cleaningcase:
                            cleaningcase.append(case)
                        if work not in cleaningwork:
                            cleaningwork.append(work)
        listcase = list(cleaningcase)
        works = list(cleaningwork)
    if start_date is not None and end_date is None:
        cleaningwork = []
        cleaningcase = []
        for case in listcase:
            for work in case.work.all():
                if work.creationDate is not None:
                        if work.creationDate >= start_date.date():
                            if case not in cleaningcase:
                                cleaningcase.append(case)
                            if work not in cleaningwork:
                                cleaningwork.append(work)
        listcase = list(cleaningcase)
        works = list(cleaningwork)
    if start_date is None and end_date is not None:
        cleaningwork = []
        cleaningcase = []
        for case in listcase:
            for work in case.work.all():
                if work.creationDate is not None:
                        if work.creationDate <= end_date.date():
                            if case not in cleaningcase:
                                cleaningcase.append(case)
                            if work not in cleaningwork:
                                cleaningwork.append(work)
        listcase = list(cleaningcase)
        works = list(cleaningwork)

    if request.method == 'POST':
        gethours = str(request.POST.get('hours'))
        workfilter = request.POST.get('workfilter')
        workfilter = int(workfilter) if workfilter is not None and workfilter != "" else None

        print(workfilter)
        if gethours == 'gethours':
            if workfilter:
                timeList = [str(x.timespent) for x in works if x.timespent is not None and x.pk == workfilter]
            else:
                timeList = [str(x.timespent) for x in works if x.timespent is not None]
            sum = timedelta()
            for i in timeList:
                (h, m, s) = i.split(':')
                d = timedelta(hours=int(h), minutes=int(m), seconds=int(s))
                sum += d
            hours = (str(sum))
            return HttpResponse(hours)

    # sum Hours
    timeList = [str(x.timespent) for x in works if x.timespent is not None]
    sum = timedelta()
    for i in timeList:
        (h, m, s) = i.split(':')
        d = timedelta(hours=int(h), minutes=int(m), seconds=int(s))
        sum += d
    hours = (str(sum))



    # print('Comparador {}'.format(comparatordate))
    context = {'boxesSearch': boxesSearch,
               'caseSearch': caseSearch,
               'worksSeach': worksSeach,
               'cases': listcase,
               'comparatordate': comparatordate,
               'boxes': boxes,
               'hours': hours,
               'works': works,
               'selectedbox': seletedBox,
               'selectedcase': seletedCase,
               'selectedwork': seletedWork,
               'end_date': end_date,
               'start_date': start_date
               }

    if request.method == 'POST':
        return render(request, 'work/getworksFilter.html', context)

    return render(request, 'work/getallworks.html', context)


@permission_required('work.change_work')
def editfield(request):

    if request.method == 'POST':
        idwork = request.POST.get('idwork')
        fieldvalue = request.POST.get('value')
        fieldtype = request.POST.get('fieldtype')
        work = get_object_or_404(Work, pk=idwork)

        if(fieldtype == "tax"):
            fieldvalue = Tax.objects.get(pk=fieldvalue)
            work.tax = fieldvalue
        elif(fieldtype == "pricePerunit"):
            fieldvalue = fieldvalue.replace(".", "")
            fieldvalue = float(fieldvalue)/100
            # fieldvalue = fieldvalue.replace(".", "")
            fieldvalue = Money(fieldvalue, BRL)

            print(fieldvalue)
            # value = Decimal(fieldvalue)
            work.pricePerunit = fieldvalue

        elif(fieldtype == "timespent"):
            t = datetime.strptime(fieldvalue, '%H:%M:%S')
            delta = timedelta(hours=t.hour, minutes=t.minute, seconds=t.second)
            work.timespent = delta

        elif(fieldtype == "creationDate"):
            t = datetime.strptime(fieldvalue, '%d/%m/%Y')
            work.creationDate = t

        else:
            work.__dict__[str(fieldtype)] = fieldvalue

        work.save()

        return HttpResponse(200)


@permission_required('case.show_work')
def getworks(request, idcase):
    comparatordate = timedelta(hours=int(10), minutes=int(00), seconds=int(00))
    case = get_object_or_404(Case, pk=idcase)
    works = case.work.all().order_by('-id')
    context = {
        'works': works,
        'case': case,
        'comparatordate': comparatordate,
    }
    return render(request, 'work/getworks.html', context)


@permission_required('work.add_work')
def addwork(request, idcase):
    case = get_object_or_404(Case, pk=idcase)
    if request.method == "POST":
        form = WorkForm(request.POST)
        now = datetime.now(timezone.utc)
        if form.is_valid():
            work = form.save(commit=False)
            work.creator = request.user.person
            work.save()
            case.work.add(work)
            case.lastupadate = now
            case.save()
            context =  "{},{},{},{}" .format(case.id, work.id, work.creator, work.creationDate.strftime('%d/%m/%Y'))
            return HttpResponse(context)
        else:
            return render(request, 'modalform.html', {'form': form})
    form = WorkForm()
    return render(request, 'modalform.html', {'form': form})


@permission_required('work.change_work')
def editwork(request, idwork):
    work = get_object_or_404(Work, pk=idwork)
    if request.method == "POST":
        form = WorkForm(request.POST, instance=work)
        if form.is_valid():
            work = form.save(commit=False)
            work.save()
            return redirect('home')
        else:
            return render(request, 'box/form.html', {'form': form})

    form = WorkForm(instance=work)
    return render(request, 'box/form.html', {'form': form})


@permission_required('work.delete_work')
def removework(request, idwork):

    work = get_object_or_404(Work, pk=idwork)

    case = get_object_or_404(Case, work=work)

    work.delete()
    works = case.work.all().order_by('-id')
    context = {
        'works': works,
        'case': case.id
    }
    return render(request, 'work/resultsearchwork.html', context)
