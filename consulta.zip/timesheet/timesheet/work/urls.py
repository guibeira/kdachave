from django.conf.urls import url
from . import views

urlpatterns = [
    # url(r'^$', listbox, name='home'),
    url(r'^/addwork/(?P<idcase>[0-9]+)/$', views.addwork, name='addwork'),
    url(r'^/getworks/(?P<idcase>[0-9]+)/$', views.getworks, name='getworks'),
    url(r'^/editwork/(?P<idwork>[0-9]+)/$', views.editwork, name='edit'),
    url(r'^/removework/(?P<idwork>[0-9]+)/$', views.removework, name='removework'),
    url(r'^/editfield$', views.editfield, name='editfield'),
    url(r'^/listworks$', views.listworks, name='listworks'),
    url(r'^/searchwork$', views.searchwork, name='searchwork'),

]
