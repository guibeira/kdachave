from django.db import models
from person.models import Person
from proxy.models import Proxy
from datetime import datetime, timezone
from django.http import JsonResponse


now = datetime.now(timezone.utc)
# Create your models here.


class Box(models.Model):
    name = models.CharField(max_length=100)
    parent = models.ForeignKey('box.Box', null=True, blank=True)
    owner = models.ForeignKey('person.Person', null=True, blank=True)

    class Meta:
        permissions = (
            ("can_make_dragndrop", "Can make drag and drop"),
            ("show_person", "Can show Pesons"),
            ("show_case", "Can show Cases"),
            )

    def __str__(self):
        return self.name


def checkhasson(boxes):
    for box in boxes:
        sons = Box.objects.filter(parent=box)
        for son in sons:
            if son not in boxes:
                boxes.append(son)
    return boxes


def callpersonsofuser(request):

	listpersons = []
	listboxes = listBoxesForAjax(request.user)
	boxes = converterdicinlist(listboxes,[])
	if request.user.has_perm('proxy.add_proxy'):
		retorno = Person.objects.all()
	else:
		retorno = getPersonbyBox(boxes, [])
	for person in retorno:
		if person not in listpersons:
			listpersons.append(person)
	l = []
	persondict = {}
	# for i in listpersons:
	# 	persondict = { "id" : str(i[0]),
	# 				   "value" : str(i[1]) }
	# 	l.append(persondict)
	
	return listpersons
	# return JsonResponse(l, safe=False)


def converterdicinlist(di, listresult):

    if type(di) == type(dict()):
        for c, v in di.items():

            if type(v) == type(list()):
                listresult.append(c)
                for x in range(len(v)):
                    if type(v[x]) == type(dict()):
                        converterdicinlist(v[x],listresult)
                    else:
                        listresult.append(v[x])
            else:
                listresult.append(c)
                listresult.append(v)

    elif(type(di) == type(list())):

        for x in range(len(di)):

            if type(di[x]) == type(dict()):
                converterdicinlist(di[x],listresult)
            else:
                listresult.append(di[x])
            tracim = ''
    else:
        listresult.append(di)

    return(listresult)


def checkHasSon(value, user, boxes):

	if(Box.objects.filter(parent=value)):
		d = {value: []}
		for box in Box.objects.filter(parent=value):
			d[value].append(box)
			if d not in boxes:
				boxes.append(d)
			checkHasSon(box,user,boxes)


def listBoxesForAjax(user):
	boxes = []
	proxies = []
	listboxes = []
	listproxy = []
	list_comparator = []
	base = []
	d = {}

    ## get logged user
	user = Person.objects.get(user=user)

	#get all the proxy for make comparatorbox
	comparatorbox = []
	proxx = Proxy.objects.exclude(creator=user)
	for i in proxx:
		if(i.box):
			comparatorbox.append(i.box)
			checkHasSon(i.box, user, comparatorbox)

	#convert elements in list
	proxylistcase = []
	repeted = []
	caseproxy_comparator = converterdicinlist(comparatorbox,proxylistcase)
    ## get direct boxes of user
	if(Box.objects.filter(owner=user)):
		for box in Box.objects.filter(owner=user):
			##check if this element aready exits to dont show again
			if(box.parent not in caseproxy_comparator ):
				d = {box: []}
				if(Box.objects.filter(parent=box)):
					for sons in Box.objects.filter(parent=box):
						d[box].append(sons)
						if d not in boxes:
							boxes.append(d)
						checkHasSon(sons, user, boxes)
				else:
					# boxes.append(d)
					base.append(box)
	else:
		listboxes = []

	preventrepetedlist = []
	if (len(boxes) > 0):
		listboxes = []
		for num in range(len(boxes)):
			comparator = boxes[num]
			for k, v in comparator.items():
				for i in boxes:
					for key, val in i.items():
						if (key != k):
							for x in range(len(v)):
								if key == v[x]:
									if key not in preventrepetedlist:
										comparator[k][x] = i
										if comparator not in listboxes:
											listboxes.append(comparator)
										if i not in repeted:
											#add the element to previne repeted elements
											repeted.append(i)
										preventrepetedlist.append(key)

	elif len(listboxes) < 1 and len(boxes) <= 1:
		listboxes = list(boxes)

	if (len(listboxes) < 1):
		if boxes:
			listboxes = list(boxes)
		else:
			listboxes = list(base)

	#remove repeted box from the listbox
	for i in repeted:
		for x in listboxes:
			if x==i:
				listboxes.remove(x)
	listresult = []
	base_comparator_box = converterdicinlist(listboxes,listresult)

	# get proxies ralated to logged user
	base_proxy = []
	for proxy in Proxy.objects.filter(person=user).filter(startDate__lte=now):
		if(proxy.endDate == None or proxy.endDate >= now):
			if proxy.box:
				d = {proxy.box: []}
				if(Box.objects.filter(parent=proxy.box)):
					for sons in Box.objects.filter(parent=proxy.box):
						d[proxy.box].append(sons)
						if d not in proxies:
							proxies.append(d)
						checkHasSon(sons, user, proxies)
				else:
					# proxies.append(d)
					listproxy.append(proxy.box)
					base_proxy.append(proxy.box)

	repeted_proxy = []
    ## check if proxies has value
	if (len(proxies) > 0):
		listproxy = []
		## get dict to compare with other elements
		for num in range(len(proxies)):
			comparator = proxies[num]
            ## get key, value of comparator elements
			for k, v in comparator.items():
                ## get element of proxies
				for i in proxies:
                    ##get key, value of proxies item
					for key, val in i.items():
                        ## check if comparator key is diferent of proxies item key
						if (key != k):
                            ## check elements values of proxies
							for x in range(len(v)):
                                ## check if proxie item key is equal of comparator value in element value position
								if key == v[x]:
									comparator[k][x] = i
									if comparator not in listproxy:
										listproxy.append(comparator)
									if i not in repeted_proxy:
										repeted_proxy.append(i)
						else:
							if i not in listproxy:
								list_comparator.append(i)
								listproxy.append(i)

	if len(listproxy) <= 1 and len(proxies) <= 1:
		listproxy = proxies
		## create base list to compare if other proxies are in original list
		base_list = []
		if(len(listproxy) > 0):

			if(type(listproxy[0]) == type(dict())):
				temporary_list = []

				for key, val in listproxy[0].items():
					if type(val) == type(list()):
						if key not in base_list:
							base_list.append(key)
						for x in range(len(val)):
							if type(val[x]) == type(dict()):
								ledic(val[x],base_list)
							else:
								if val[x] not in base_list:
									base_list.append(val[x])
					else:
						if val not in base_list:
							base_list.append(val)

	            ##check if other proxies are in original list
				for x in range(len(list_comparator)):

					val = list(list_comparator[x])
					if val[0] not in base_list:
						temporary_list = list(listproxy[0].values())
						temporary_list[0].append(list_comparator[x])
	                    ## prevent the sons of sons that aren't in original list be add one more time
						if type(list(list_comparator[x].values())[0][0]) == type(dict()):
							base_list.append(list(list(list_comparator[x].values())[0][0].keys())[0])

	            ## add value of new proxy into original list
				if len(temporary_list) > 0:
					keylistproxy = list(listproxy[0].keys())
					listproxy[0][keylistproxy[0]] = temporary_list[0]

	for i in repeted_proxy:
		for x in listproxy:
			if i==x:
				listproxy.remove(x)

	#create list based in the new listproxy for check if proxys wothot sons aready in listproxy
	listresultproxy = []
	base_comparator_proxy = converterdicinlist(listproxy,listresultproxy)
	for i in base_proxy:
		if i not in base_comparator_proxy:
			listproxy.append(i)

	comparator_proxy = []
	for  i in base_comparator_box:
		comparator_proxy.append(str(i))

	temporary_list_box = []
	for x in range(len(listproxy)):
		if( type(listproxy[x]) == type(list()) ):
			val = str(list(list_comparator[x])[0])
		elif( type(listproxy[x]) == type(dict()) ):
			val = list(listproxy[x])
			val = str(val[0])
		else:
			val = str(listproxy[x])
		if val not in comparator_proxy:
			if listproxy[x] not in temporary_list_box:
				temporary_list_box.append(listproxy[x])

				if(type(listproxy[x]) == type(dict())):
					if(len(list(listproxy[x].values())[0]) > 0):
						if(type(list(listproxy[x].values())[0][0]) == type(dict())):
							comparator_proxy.append(str(list(list(listproxy[x].values())[0][0].keys())[0]))
							if(len(list(list(listproxy[x].values())[0][0].values())[0]) > 0 ):
								var = (list(list(listproxy[x].values())[0][0].values())[0][0])
								if(type(var) == type(dict())):
									if(len(list(var.values())[0]) > 0):
										read(var,comparator_proxy)
									else:
										comparator_proxy.append(str(list(var.keys())[0]))

								elif(type(val) == type(str())):
									comparator_proxy.append(str(var))
								else:
									comparator_proxy.append(str(list(var)[0]))
				else:
					comparator_proxy.append(listproxy[x])
		else:
			pass

	for i in comparator_proxy:
		for num in temporary_list_box:
			if(type(num) == type(dict())):
				if( str(list(num.keys())[0]) == i ):
					temporary_list_box.remove(num)

	if len(temporary_list_box) > 0:

		if (len(listboxes) > 0):

			if(type(listboxes[0]) == type(dict())):
				keylistbox = list(listboxes[0].keys())
				for i in range(len(temporary_list_box)):
					listboxes.append(temporary_list_box[i])
			else:
				father = listboxes[0]
				d = {father:[]}
				listboxes[0] = d
				for i in range(len(temporary_list_box)):
					listboxes.append(temporary_list_box[i])
		else:
			#if person dont have box, but have only proxy
			listboxes = temporary_list_box

	listabasebox = []
	listadebox = converterdicinlist(listboxes, listabasebox)

	return (listboxes)


def read(var, comparator_proxy,):

	if(type(var) == type(dict())):

		comparator_proxy.append(str(list(var.keys())[0]))
		if(len(list(var.values())[0]) > 0):
			if(type(list(var.values())[0][0]) ==  type(dict())):
				if(len(list(var.values())[0][0])>0):
					read(list(var.values())[0][0],comparator_proxy)
			else:
				comparator_proxy.append(str(list(var.values())[0][0]))
	else:
		comparator_proxy.append(str(var))
