from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^/loadbox$', views.listBoxAjax, name='update'),
    url(r'^/updatebox$', views.update, name='update'),
    url(r'^/deletebox$', views.delete, name='delete'),
    url(r'^/callpersonsofuser$', views.callpersonsofuser, name='callpersonsofuser'),
    url(r'^/newbox/(?P<parentId>[0-9]+)/$', views.newbox, name='newbox'),
	url(r'^/$', views.listbox, name='home'),
    url(r'^/editbox/(?P<id>[0-9]+)/$', views.editbox, name = 'editbox'),
    url(r'^/getPersonsInBox/(?P<idbox>[0-9]+)/$', views.getPersonsInBox, name='getPersonsInBox'),
    url(r'^/deletepersonofbox/(?P<idbox>[0-9]+)/(?P<idperson>[0-9]+)/$', views.deletepersonofbox, name='deletepersonofbox'),
    url(r'^/clonepersoninbox/(?P<iddragperson>[0-9]+)/(?P<idbox>[0-9]+)/$', views.clonepersoninbox, name='clonepersoninbox'),
    url(r'^/getCasesInBox/(?P<idbox>[0-9]+)/$', views.getCasesInBox, name='getCasesInBox'),
    url(r'^/editname$', views.editnamebox, name='editname'),


]
