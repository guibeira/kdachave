from django import template
from django.template.defaultfilters import stringfilter
from django.template import Context, Template
from box.views import getCasesInBox
from case.templatetags.case_check_has_son import calllediccase

register = template.Library()
varhtml = ''
context = {}


def ledic(di, request):
    box_add = request.user.has_perm('box.add_box')
    box_edit = request.user.has_perm('box.change_box')
    box_delete = request.user.has_perm('box.delete_box')
    box_show_person = request.user.has_perm('box.show_person')
    box_show_case = request.user.has_perm('box.show_case')
    global varhtml
    global context
    for c, v in di.items():
        if type(v) == type(list()):
            ## is parent
            varhtml += '<li class="li-tree" id="{}" ><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span class=" owner-name">{}</span> </br>\n'.format(c.pk, c.pk, c.pk, c.name.lower(), c.pk, c, c, c.owner)
            varhtml += '<div class="box-icons">\n'
            varhtml += '<div class="box-icons-top">\n'
            if box_add:
                varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus"  data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(c.pk)
            if box_edit:
                varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true" ></i>\n'.format(c.pk)
            if box_delete:
                varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true" ></i>\n'.format(c.pk)
            varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="box-icons-down">\n'
            if box_show_person:
                varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(c.pk)
            if box_show_case:
                varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '<div idbox={} class="casesdetail detailcases{} hidden">\n'.format(c.pk,c.pk)
            varhtml += drawCasesOfBox(c.pk, request)
            varhtml += '</div>\n'
            varhtml += '<ul class="ul-tree drag">\n'
            if(len(v)== 0):

                varhtml += '</ul>\n'
                varhtml += '</li>\n'
            else:
                for x in range(len(v)):
                    if type(v[x]) == type(dict()):
                        # varhtml += 'LEDIC 1 {}\n'.format(v[x])
                        ledic(v[x], request)

                        total = v[x].values()
                        if x+1 == len(v):
                            for i in range(len(total)):
                                varhtml += '</ul>\n'
                                varhtml += '</li>\n'
                    else:
                        ## is son
                        varhtml += '<li class="li-tree" id="{}" ><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span  class=" owner-name">{}</span> </br>\n'.format(v[x].pk, v[x].pk, v[x].pk, v[x].name.lower(), v[x].pk, v[x], v[x], v[x].owner)

                        varhtml += '<div class="box-icons">\n'
                        varhtml += '<div class="box-icons-top">\n'
                        if box_add:
                            varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus" data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(v[x].pk)
                        if box_edit:
                            varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(v[x].pk)
                        if box_delete:
                            varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n'.format(v[x].pk)
                        varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="box-icons-down">\n'
                        if box_show_person:
                            varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons" ></i>\n'.format(v[x].pk)
                        if box_show_case:
                            varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(v[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(v[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '<div idbox={} class="casesdetail detailcases{} hidden">\n'.format(v[x].pk,v[x].pk)
                        varhtml += drawCasesOfBox(v[x].pk, request)
                        varhtml += '</div>\n'
                        varhtml += '<ul class="ul-tree drag"></ul></li>\n'
                        if x+1 == len(v):
                            varhtml += '</ul>\n'
                            varhtml += '</li>\n'

        else:
            ## is parent
            varhtml += '<li class="li-tree" id="{}" ><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span  class=" owner-name">{}</span> </br>\n'.format(c.pk,c.pk,c.pk, c.name.lower(), c.pk, c, c, c.owner)
            varhtml += '<div class="box-icons">\n'
            varhtml += '<div class="box-icons-top">\n'
            if box_add:
                varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus" data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(c.pk)
            if box_edit:
                varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" aria-hidden="true" data-toggle="tooltip" title="edit"></i>\n'.format(c.pk)
            if box_delete:
                varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n'.format(c.pk)
            varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="box-icons-down">\n'
            if box_show_person:
                varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(c.pk)
            if box_show_case:
                varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '<div idbox={} class="casesdetail detailcases{} hidden">\n'.format(c.pk,c.pk)
            varhtml += drawCasesOfBox(c.pk, request)
            varhtml += '</div>\n'
            varhtml += '<ul class="ul-tree drag">\n'
            ## is son
            varhtml += '<li class="li-tree" id="{}" ><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree"><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span  class=" owner-name">{}</span> </br>\n'.format(v.pk, v.pk, v.pk, v.name.lower(), v.pk, v, v, v.owner)
            varhtml += '<div class="box-icons">\n'
            varhtml += '<div class="box-icons-top">\n'
            if box_add:
                varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus" data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(v.pk)
            if box_edit:
                varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(v.pk)
            if box_delete:
                varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i> \n'.format(v.pk)
            varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="box-icons-down">\n'
            if box_show_person:
                varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(v.pk)
            if box_show_case:
                varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(v.pk)
            varhtml += '</div>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(v.pk)
            varhtml += '</div>\n'
            varhtml += '<div idbox={} class="casesdetail detailcases{}  hidden">\n'.format(v.pk,v.pk)
            varhtml += drawCasesOfBox(v.pk, request)
            varhtml += '</div>\n'
            varhtml += '</li>\n'
            varhtml += '</ul>\n'
            varhtml += '</li>\n'


def callledic(value, request):


    box_add = request.user.has_perm('box.add_box')
    box_edit = request.user.has_perm('box.change_box')
    box_delete = request.user.has_perm('box.delete_box')
    box_show_person = request.user.has_perm('box.show_person')
    box_show_case = request.user.has_perm('box.show_case')
    global varhtml
    global context
    value = [value]
    if(type(value[0]) == type(dict())):
        for key, val in value[0].items():
            ## check if have son
            if type(val) == type(list()):
                ## is parent
                if len(val) >1:
                    last = val[-1]
                else:
                    last = val
                varhtml += '<li  class="home li-tree" id="{}"><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span  class=" owner-name">{}</span> </br>\n'.format(key.pk, key.pk, key.pk, key.name.lower(), key.pk, key, key, key.owner)
                varhtml += '<div class="box-icons">\n'
                varhtml += '<div class="box-icons-top">\n'
                if box_add:
                    varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus"data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(key.pk)
                if box_edit:
                    varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(key.pk)
                varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="box-icons-down">\n'
                if box_show_person:
                    varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(key.pk)
                if box_show_case:
                    varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(key.pk)
                varhtml += '</div>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="proxiesdetail detailproxies{}"></div>\n'.format(key.pk)
                varhtml += '</div>\n'
                varhtml += '<div idbox={} class="casesdetail detailcases{} hidden">\n'.format(key.pk, key.pk)

                varhtml += drawCasesOfBox(key.pk, request)

                varhtml += '</div>'
                varhtml += '<ul>\n'

                if(len(val)< 1):
                    varhtml += '</ul>\n'
                    varhtml += '</li>\n'

                for x in range(len(val)):
                    if type(val[x]) == type(dict()):
                        # varhtml += 'LEDIC 2 {}\n'.format(val[x])
                        ledic(val[x], request)
                        total = val[x].values()
                        if x+1 == len(val):
                            for i in range(len(total)):
                                varhtml += '</ul>\n'
                                varhtml += '</li>\n'

                    else:


                        varhtml += '<li class="li-tree" id="{}" ><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span class=" owner-name">{}</span> </br>\n'.format(val[x].pk,val[x].pk,val[x].pk, val[x].name.lower(), val[x].pk, val[x], val[x], val[x].owner)
                        varhtml += '<div class="box-icons">\n'
                        varhtml += '<div class="box-icons-top">\n'
                        if box_add:
                            varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus" data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(val[x].pk)
                        if box_edit:
                            varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(val[x].pk)
                        if box_delete:
                            varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n' .format(val[x].pk)
                        varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="box-icons-down">\n'
                        if box_show_person:
                            varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(val[x].pk)
                        if box_show_case:
                            varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(val[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(val[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '<div idbox={} class="casesdetail detailcases{} hidden ">'.format(val[x].pk,val[x].pk)
                        varhtml += drawCasesOfBox(val[x].pk, request)
                        varhtml += '</div>\n'
                        varhtml += '</li>\n'
                        if x+1 == len(val):
                            varhtml += '</ul>\n'
                            varhtml += '</li>\n'

            else:
                varhtml += '<li class="li-tree" id="{}"><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree"><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span class=" owner-name">{}</span> </br>\n'.format(val.pk,val.pk,val.pk, val.name.lower(), val.pk, val,  val, val.owner)
                varhtml += '<div class="box-icons">\n'
                varhtml += '<div class="box-icons-top">\n'
                if box_add:
                    varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus" data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(val.pk)
                if box_edit:
                    varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(val.pk)
                if box_delete:
                    varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i> \n'.format(val.pk)
                varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="box-icons-down">\n'
                if box_show_person:
                    varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(val.pk)
                if box_show_case:
                    varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(val.pk)
                varhtml += '</div>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(val.pk)
                varhtml += '</div>\n'
                varhtml += '<div idbox={} class="casesdetail detailcases{} hidden ">'.format(val.pk,val.pk)
                varhtml += drawCasesOfBox(val.pk, request)
                varhtml += '</div>\n'
                varhtml += '</li>\n'

        ret = printHtml(varhtml, context)
        varhtml = ''
        return ret
    else:
        varhtml += '<li class="li-tree home" id="{}" home="home" ><div idbox="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamebox" idbox="{}" nameelement="{}">{}</div> <span class="owner-name">{}</span> </br>\n'.format(value[0].pk,value[0].pk,value[0].pk, value[0].name.lower(), value[0].pk, value[0], value[0], value[0].owner)
        varhtml += '<div class="box-icons">\n'
        varhtml += '<div class="box-icons-top">\n'
        if box_add:
            varhtml += '<i idbox={} class="newbox glyphicon glyphicon-plus" data-toggle="tooltip" title="add new box" aria-hidden="true"></i>\n'.format(value[0].pk)
        if box_edit:
            varhtml += '<i idbox= {} class="edit fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i> \n'.format(value[0].pk)
        if box_delete:
            varhtml += '<i idbox={} class="deletebox glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n'.format(value[0].pk)
        varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
        varhtml += '</div>\n'
        varhtml += '<div class="box-icons-down">\n'
        if box_show_person:
            varhtml += '<i idbox= {} class="showproxies fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(value[0].pk)
        if box_show_case:
            varhtml += '<i idbox= {} class="showcases glyphicon glyphicon-tags" data-toggle="tooltip" title="show cases"></i>\n'.format(value[0].pk)
        varhtml += '</div>\n'
        varhtml += '</div>\n'
        varhtml += '<div class="proxiesdetail detailproxies{} hidden"></div>\n'.format(value[0].pk)
        varhtml += '</div>\n'
        varhtml += '<div idbox={} class="casesdetail detailcases{} hidden">'.format(value[0].pk,value[0].pk)
        varhtml += drawCasesOfBox(value[0].pk, request)
        varhtml += '</div>\n'
        varhtml += '</li>\n'
        ret = printHtml(varhtml, context)
        varhtml = ''
        return ret


def printHtml(varhtml, context):

    t = Template(varhtml)
    c = Context(context)
    html = t.render(c)
    varhtml = ''
    return html

def drawCasesOfBox(boxid, request):
    varhtml = ''
    resultado = getCasesInBox(request, boxid , tobox=True)
    casesofbox = ''
    varhtml += '<div class="row tree-container-content">\n'
    varhtml += '<div class="operational-content">\n'
    varhtml += '<ul class="cases-id-list" style="display:none">\n'
    varhtml += '<li class="li-tree ">'
    varhtml += '<div idcase="0" id="b-0" nameelement="Cases" class="a-tree-unique-style newcase">\n'
    varhtml += '<div class="box-iconsd">\n'
    varhtml += '<div class="box-icons-topd">\n'
    varhtml += '<i idcase="0" class="newcase glyphicon glyphicon-plus"  data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'
    varhtml += '</div>\n'
    varhtml += '</div>\n'
    varhtml += '</div>\n'
    varhtml += '<ul>\n'

    for case in resultado['cases']:
        casesofbox += calllediccase(case, request.user)


    varhtml += str(casesofbox)
    varhtml += '</ul>'
    varhtml += '</li>'
    varhtml += '</ul>'
    varhtml += '</div>'
    varhtml += '</div>'
    return varhtml

register.filter('callledic', callledic)
