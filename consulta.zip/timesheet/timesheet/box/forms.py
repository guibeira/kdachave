from django import forms
from box.models import Box, checkhasson
from person.models import Person
from proxy.models import Proxy, getPersonbyBox


class NewBoxForm(forms.ModelForm):
    class Meta:
        model = Box
        fields = ('name',)


class BoxForm(forms.Form):

    DEFAULT = ()
    owner = forms.ChoiceField(choices=DEFAULT)

    def __init__(self, request=None, box=None, listperson=None, *args, **kwargs):
            super(BoxForm, self).__init__(*args, **kwargs)
            # print(box)
            proxysInBox = Proxy.objects.filter(box=box)
            personToRemove = []
            for proxy in proxysInBox:
                for person in proxy.person.all():
                    personToRemove.append(person)
            if request.user:
                tosend = []
                send = []
                retorno = []
                if request.user.has_perm('proxy.add_proxy'):
                    # retorno = Person.objects.all()
                    for p in Person.objects.all():
                        retorno.append(p)
                else:
                    boxes = Box.objects.filter(
                        owner=request.user.person)
                    for box in boxes:
                        if box not in tosend:
                            tosend.append(box)
                    proxys = Proxy.objects.filter(person=request.user.person)
                    for proxy in proxys:
                        if(proxy.box) and (proxy.box not in tosend):
                            tosend.append(proxy.box)
                    results = checkhasson(tosend)
                    listofperson = []
                    retorno = getPersonbyBox(results, listofperson)

                for p in personToRemove:
                    if p in retorno:
                        retorno.remove(p)

                for person in retorno:
                    # if(person != request.user.person):
                    if listperson:
                        if person not in listperson:
                            send.append((person.pk, person))
                    else:
                        send.append((person.pk, person))

            else:
                send = []
            self.fields['owner'].choices = send

    # class Meta:
    #     model = Box
    #     fields = ('owner',)
