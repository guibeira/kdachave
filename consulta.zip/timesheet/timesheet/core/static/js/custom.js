
function newproxy(id){
  var durl = "/proxy/newproxy/"+id;
  $.ajax({
      type: "GET",
      url: durl,
      beforeSend: function(xhr, settings) {
        xhr.setRequestHeader("X-CSRFToken", csrftoken);
      },
      success: function(data){
          $('.modal-title').html('Add Person');
          $('.modal-body').html(data);
          $('#myModal').modal('show');
          $('.modalform').attr("action", '/proxy/newproxy/'+id+'/');
          formProxyByAjax($('.modal-body').find('form'));
      }
  });
}

function editnamebox(obj){

    name = obj.attr('nameelement');
    id = obj.attr('idbox');
    // include = $("<input id='nameboxedition' class='text-center' type='text' name='namebox' value='"+name+"'><br>");
    include = $("<input id='nameboxedition' class='text-center' type='text' name='namebox' value='"+name+"'><br>");

    box = obj;
    obj.empty();
    obj.append(include);
    $('input', obj).focus().select();
    $('input', obj).focusout(function(e){
        namebox = $(this).val();
        if (namebox != name && namebox != ""){

                var durl = "/box/editname";
                $.ajax({
                    type: "POST",
                    data: {
                        'idbox' : id,
                        'namebox' : namebox,
                    },
                    url: durl,
                    beforeSend: function(xhr, settings) {
                      xhr.setRequestHeader("X-CSRFToken", csrftoken);
                    },
                    success: function(data){

                        box.remove('#nameboxedition');
                        // $('#nameboxedition').blur();
                        box.text(namebox);
                        box.attr('nameelement', namebox)
                        box.parent().attr('nameelement', namebox);
                        // box.siblings().fadeIn();
                    }
                });


        }else{
            box.remove('#nameboxedition');
            box.text(name);
            // box.siblings().fadeIn();
        }

        $(this).unbind();

    })
    $('input', obj).keypress(function(e){

        if(e.which == 13) {
            $(this).focusout();
        }

    })
    // $(this).unbind();
}


function editnameofcase(editnamecase, permission){
    if(permission){
        var csrftoken = $.cookie('csrftoken');
        name = editnamecase.attr('nameelement');
        id = editnamecase.attr('idcase');
        include = $("<input id='nameboxedition' class='text-center' type='text' name='namebox' value='"+name+"'><br>");

        include.on('click', function(e){
        });

        box = editnamecase
        editnamecase.empty();
        editnamecase.append(include);
        $('input', editnamecase).focus().select();
        $('input', editnamecase).focusout(function(e){
            namecase = $(this).val();
            if (namecase != name && namecase != "" ){

                    var durl = "/case/editnamecase";
                    $.ajax({
                        type: "POST",
                        data: {
                            'idcase' : id,
                            'namecase' : namecase,
                        },
                        url: durl,
                        beforeSend: function(xhr, settings) {
                          xhr.setRequestHeader("X-CSRFToken", csrftoken);
                        },
                        success: function(data){
                            box.text(namecase);
                            box.attr('nameelement', namecase)
                        }
                    });

            }else{
                box.remove('#nameboxedition');
                box.text(name);
            }

            $(this).unbind();
        })
        $('input', editnamecase).keypress(function(e){
            if(e.which == 13) {
                $(this).focusout();
            }
        });
    }
}

function ajaxGetCaseInBox(id){
    //call ajax to get the cases of this box
    var durl = "/box/getCasesInBox/"+id+"/";
    $.ajax({
        type: "GET",
        url: durl,
        beforeSend: function(xhr, settings) {
          xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        success: function(data){
            if(data){
                $('.detailcases'+id).html('');
                var thishtml = $.parseHTML(data);
                $('.detailcases'+id).html(thishtml);
                $("#cases-id-list"+id).jOrgChart({
                    chartElement : '.detailcases'+id,
                    dragAndDrop  : true
                });

                //recize body
                setTimeout(function(){
                    var organizational_max_width = $('#chart .jOrgChart table:first-child').width() + 285;
                    var operational_max_width = $('#chart1 .jOrgChart table:first-child').width() + 285;

                    if(organizational_max_width > $('body').width() || operational_max_width > $('body').width()){
                        if(organizational_max_width > operational_max_width){
                            $('#wrapper').css('width',organizational_max_width);
                        }else{
                            $('#wrapper').css('width',operational_max_width);
                        }
                    }
                    cont =1;
                }, 100);

            }
        }
    });
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                    //////
//////                                          START WORK JS                                             //////
//////                                                                                                    //////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var csrftoken = $.cookie('csrftoken');
function newwork(id){
    var durl = "/work/addwork/"+id;
    $.ajax({
        type: "GET",
        url: durl,
        beforeSend: function(xhr, settings) {
          xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        success: function(data){
            $('.modal-title').html('New work');
            $('.modal-body').html(data);
            $('#myModal').modal('show');
            $('.modalform').attr("action", '/work/addwork/'+id+'/');
        }
    });
}

////function to limit length of tr in all cases
function worklimitlength(){
    $('.tbody-work').each(function(){
        for(i=0; i < $(this).children().length; i++){
            if(i >= 5){
                $($(this).children()[i]).addClass('hidden');
            }

        }
    });
}

//function to show all works in specific case
function showallworks(obj, showall){
    var idcase = obj.attr('idcase');
    if(!showall){
        $('.tbody-work'+idcase).each(function(){
            for(i=0; i < $(this).children().length; i++){
                if($($(this).children()[i]).hasClass('hidden')){
                    $($(this).children()[i]).removeClass('hidden');
                }
            }
        });
        obj.text('show less');
        return true;
    }else{
        $('.tbody-work'+idcase).each(function(){
            for(i=0; i <  $(this).children().length; i++){
                if(i >= 5){
                    $($(this).children()[i]).addClass('hidden');
                }
            }
        });
        obj.text('show all');
        return false;
    }
}

function removework(idwork, idcase){
  // idcase = idcase.parents('table').siblings('a').attr('idcase');
  var r = confirm("Are you sure you want remove this work ?");
  if (r == true) {
      var durl = "/work/removework/"+idwork;
      $.ajax({
          type: "GET",
          url: durl,
          beforeSend: function(xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
          },
          success: function(data){
             console.log(idcase)
            console.log($(document).find('.tbody-work'+idcase))
            console.log($('.tbody-work'+idcase));
              $('.tbody-work'+idcase, $(document)).html(data);
              $('.remove-work-of-case').on('click', function(){
                  removework($(this).attr('idwork'), $(this).attr('idcase'));
              });

              //used to update field elements in work table.
              $('.inputelement').on('click',function(){
                  if($(this).hasClass('inputelement')){
                      updateWorkTableField($(this));
                  }
              });

              worklimitlength();

              var showall = false;
              $('.showallworks').on('click', function(){
                  showall = showallworks($(this), showall);
              });
          }
      });
  }
}

function addnewwork(id){
    var durl = "/work/addwork/"+id+"/";
    $.ajax({
        type: "POST",
        url: durl,
        beforeSend: function(xhr, settings) {
          xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        success: function(data){
            //prepend new <tr> with the new value

            var res = data.split(",");
            console.log(res)
            var varhtml = "<tr>";
                varhtml += "<td idwork='"+res[1]+"' fieldtype='creator' >"+res[2]+"</td>";
                varhtml += "<td class='inputelement' idwork='"+res[1]+"' fieldtype='description'></td>";
                varhtml += "<td class='inputelement' idwork='"+res[1]+"' fieldtype='creationDate'>"+res[3]+"</td>";
                varhtml += "<td class='inputelement' idwork='"+res[1]+"' fieldtype='timespent'>00:00:00</td>";
                varhtml += "<td class='inputelement' idwork='"+res[1]+"' fieldtype='pricePerunit'></td>";
                varhtml += "<td class='inputelement' idwork='"+res[1]+"' fieldtype='quantity'></td>";
                varhtml += "<td class='inputelement' idwork='"+res[1]+"' fieldtype='tax'></td>";
                varhtml += "<td><i idcase='"+res[0]+"' idwork='"+res[1]+"' class='remove-work-of-case btn btn-primary btn-danger' data-toggle='tooltip' title='remove work' aria-hidden='true'><span class='glyphicon glyphicon-remove-sign'></span></i></td>";
            varhtml += "</tr>";

            //parsehtml to trgger click on td element
            var thishtml2 = $.parseHTML(varhtml);
            $('.inputelement', $(thishtml2)).on('click',function(){
                updateWorkTableField($(this));

            });
            //parsehtml to trigger click on remove-work-of-case
            $('.remove-work-of-case', $(thishtml2)).on('click',function(){
                removework($(this).attr('idwork'), $(this).attr('idcase'));
            });

            //prepend new work
            $('.tbody-work'+id).prepend(thishtml2);

            //auto focus in description
            $(".inputelement[idwork='"+res[1]+"'][fieldtype='description']").trigger( "click" );

        }
    });
}

function updateWorkTableField(obj){

    var value = obj.text();
    var field = obj;
    var idwork = obj.attr('idwork');
    var fieldtype = obj.attr('fieldtype');
    var inputvalue;
    var include = $('<input />');
    if(fieldtype == 'description'){
        include = $("<textarea rows='10' cols='40' name='namebox' class='edit-work form-control'>"+value+"</textarea>");
    }else if(fieldtype == 'creationDate'){
        include = $("<div style='position: relative'><input class='text-center edit-work creationDate' type='text' name='namebox' value='"+value+"'></div><br>");
    }else if(fieldtype == 'timespent'){
        include = $("<input class='text-center edit-work time'  name='namebox' pattern='^\d+:\d{2}:\d{2}$' value='"+value+"'><br>");
    }else if (fieldtype == 'tax'){

        include = $("<select name='box' class='form-control edit-work chosen-select'></select>");
        var options = "";
        if(obj.hasClass('inputelement')){
            var durl = "/tax/gettaxestowork";
            $.ajax({
                type: "POST",
                url: durl,
                beforeSend: function(xhr, settings) {
                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                },
                success: function(data){
                        options += '<option value="">---------</option>';
                    for (i=0; i< data.length; i++){
                        options += '<option value="'+data[i].id+'">'+data[i].name+' - ('+data[i].percentage+'%)</option>';
                    }
                    include.html(options);
                    obj.removeClass('inputelement');
                    $('.chosen-select').chosen({ width: '95%' });
                    $('.chosen-select-deselect').chosen({ allow_single_deselect: true });
                    $('.edit-work').on('change', function(){
                        value = $('.edit-work :selected').text();
                        inputvalue = $('.edit-work :selected').val();
                        if(!obj.hasClass('inputelement')){
                            if (inputvalue != value && inputvalue != ""){
                                ajaxSaveEditWork(idwork,inputvalue,fieldtype,field,value, obj);
                            }else{
                                field.remove('.edit-work');
                                field.text(value);
                            }
                        }
                    });
                }
            });

        }
    }else if (fieldtype == 'pricePerunit'){
        include = $("<input class='text-center money edit-work' type='text' name='namebox' value='"+value+"'><br>");
    }else{
        include = $("<input class='text-center money edit-work' type='number' name='namebox' value='"+value+"'><br>");
    }

    ////change the text inside element to a input element
    obj.empty();
    obj.append(include);

    $('.creationDate', obj).datetimepicker({

        format: 'DD/MM/YYYY',
    });

    ////put focus on input element
    $('.edit-work', obj).focus().select();
    ////take the focus out of the input element
    $('.edit-work', obj).focusout(function(e){
        if(fieldtype == "timespent"){
            if(!obj.hasClass('inputelement')){
                obj.addClass('inputelement');
            }
            inputvalue = $(this).val();
            var res = inputvalue.split(":");
            if(res[0] > 23 || res[1]> 60 || res[2]>60){
                console.log('maior');
            }

            ////check if value change or is not empty
            if (inputvalue != value && inputvalue != ""){
                if(res[0] > 23 || res[1]> 59 || res[2]>59){
                    toastr.warning("Please enter a valid time");
                }else{
                    ajaxSaveEditWork(idwork,inputvalue,fieldtype,field,value, obj);
                }


            }else{
                if(inputvalue != ""){
                    toastr.warning("Please enter a valid time");
                }
                field.remove('.edit-work');
                field.text(value);
            }
            $(this).unbind();
        }
        if(fieldtype != "tax"){
            if(!obj.hasClass('inputelement')){
                obj.addClass('inputelement');
            }
            inputvalue = $(this).val();
            ////check if value change or is not empty
            if (inputvalue != value && inputvalue != ""){
                    ajaxSaveEditWork(idwork,inputvalue,fieldtype,field,value, obj);
            }else{
                field.remove('.edit-work');
                field.text(value);
            }
            $(this).unbind();
        }
    });
    $('.edit-work', obj).keypress(function(e){
        if(e.which == 13) {
            if(!obj.hasClass('inputelement')){
                obj.addClass('inputelement');
            }
            $(this).focusout();
        }
    });
}

function ajaxSaveEditWork(idwork,inputvalue,fieldtype,field,value, obj){

        var durl = "/work/editfield";
        $.ajax({
            type: "POST",
            data: {
                'idwork' : idwork,
                'value' : inputvalue,
                'fieldtype':fieldtype
            },
            url: durl,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                field.remove('.edit-work');
                if(fieldtype=="tax"){
                    field.text(value);
                }else{
                    field.text(inputvalue);
                }
                obj.addClass('inputelement');
                toastr.success("Changed successfully");
            }
        });

}

var originalTbody = "";
function ajaxSearchWork(obj){

    var idcase = obj.attr('idcase');
    if(originalTbody == ""){
        originalTbody = $('.tbody-work'+idcase).html();
    }

    if(obj.val().length > 2){
        var searchContent = obj.val();
        ////search if user has the corresponding work in case
        var durl = "/work/searchwork";
        $.ajax({
            type: "POST",
            url: durl,
            data: {
                'idcase':idcase,
                'searchContent':searchContent,
            },
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('.tbody-work'+idcase).html(data);
                $('.remove-work-of-case').on('click', function(){
                    removework($(this).attr('idwork'), $(this));
                });

                //used to update field elements in work table.
                $('.inputelement').on('click',function(){
                    if($(this).hasClass('inputelement')){
                        updateWorkTableField($(this));
                    }
                });
            }
        });
    }else if (obj.val().length == 0) {
        $('.tbody-work'+idcase).html(originalTbody);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                    //////
//////                                          END WORK JS                                               //////
//////                                                                                                    //////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function formProxyByAjax(form){
    form.submit(function() {
        var data = form.serializeArray();
        var url = form.attr('action');
        $.ajax({
            type: "POST",
            data: data,
            url: url,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('#myModal').modal('hide');
                if(data.new){
                    ajaxGetPersonsInBox(data.new);
                }
                if(data.old){
                    ajaxGetPersonsInBox(data.old);
                }else{
                    ajaxGetPersonsInBox(data);
                }
            }
        });
        return false;
    });
}

function ajaxGetPersonsInBox(id){
    var durl = "/box/getPersonsInBox/"+id;
    $.ajax({
        type: "GET",
        url: durl,
        beforeSend: function(xhr, settings) {
          xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        success: function(data){
              if(data){
                  var thishtml = $.parseHTML(data);
                  $('.delete-person-of-box', $(thishtml)).on('click', function(){
                       deletepersonofbox($(this).attr('idbox'), $(this).attr('idperson'));
                  });

                  $('.editcase', $(thishtml)).on('click', function(){
                      editproxy($(this).attr('idproxy'), proxyeditbox);
                  });

                  $('.newproxy', $(thishtml)).on('click', function(){
                      if($(this).children().attr('idbox')){
                          newproxy($(this).children().attr('idbox'));
                      }
                  });

                  var originalcontent = "";
                  $('.searchproxy',$(thishtml)).keyup(function(){
                      var idbox = $(this).attr('idbox');
                      var searchPersonContent = $(this).val();
                      if(originalcontent == ""){
                           originalcontent = $('.list-proxy-person'+idbox).html();
                      }
                      if(searchPersonContent.length > 2){
                          //ajax search person in proxy
                          var durl = "/person/searchpersoninproxy";
                          $.ajax({
                              type: "POST",
                              data: {
                                  'type': 'box',
                                  'id' : idbox,
                                  'searchPersonContent' : searchPersonContent,
                              },
                              url: durl,
                              beforeSend: function(xhr, settings) {
                                xhr.setRequestHeader("X-CSRFToken", csrftoken);
                              },
                              success: function(data){
                                  var thishtml = $.parseHTML(data);

                                  $('.delete-person-of-box', $(thishtml)).on('click', function(){
                                       deletepersonofbox($(this).attr('idbox'), $(this).attr('idperson'));
                                  });

                                  $('.editcase', $(thishtml)).on('click', function(){
                                      editproxy($(this).attr('idproxy'), proxyeditbox);
                                  });

                                  $('.newproxy', $(thishtml)).on('click', function(){
                                      if($(this).children().attr('idbox')){
                                          newproxy($(this).children().attr('idbox'));
                                      }
                                  });

                                  $('.list-proxy-person'+idbox).html(thishtml);
                              }
                          });

                      }else{
                          $('.list-proxy-person'+idbox).html(originalcontent);
                      }
                  });

                  ////trigger mouse start
                  var oldMouseStart = $.ui.draggable.prototype._mouseStart;
                  $.ui.draggable.prototype._mouseStart = function (event, overrideHandle, noActivation) {
                      this._trigger("beforeStart", event, this._uiHash());
                      oldMouseStart.apply(this, [event, overrideHandle, noActivation]);
                  };
                  $('.li-person', $(thishtml)).draggable({
                      cursor      : 'move',
                      distance    : 40,
                      helper      : 'clone',
                      opacity     : 0.8,
                      revert      : 'invalid',
                      revertDuration : 100,
                      snap        : 'div.node.expanded',
                      snapMode    : 'inner',
                      stack       : 'div.node'
                  });

                  $('.detailproxies'+id).html(thishtml);

              }
        }
    });
}


function editproxy(id, proxyeditbox){
    if(proxyeditbox){
        var durl = "/proxy/editproxy/"+id;
        $.ajax({
            type: "GET",
            url: durl,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('.modal-title').html('Edit Persons');
                $('.modal-body').html(data);
                $('#myModal').modal('show');
                $('.modalform').attr("action", '/proxy/editproxy/'+id+'/');
                formProxyByAjax($('.modal-body').find('form'));
            }
        });
    }
}

//delete person from box
function deletepersonofbox(idbox, idperson){
  var r = confirm("Are you sure you want delete this person ?");
  if (r == true) {
      var durl = "/box/deletepersonofbox/"+idbox+'/'+idperson;
      $.ajax({
          type: "GET",
          url: durl,
          beforeSend: function(xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
          },
          success: function(data){
              if(data == 200){
                  ajaxGetPersonsInBox(idbox);
              }else {
                  location.reload();
              }
          }
      });
  }
}

function repaint(){
    $('.showproxies').each(function(){
        $(this).css("color" , "#000000");
        $(this).removeClass("fa-2x");
        // console.log($(this).css("color" , "#000000"));
    })
}

$(document).on('mouseleave', '.node', function(){
    toclear = $(this);

    toclear.find('.proxiesdetail').fadeOut('slow');
    toclear.find('.showproxies').removeClass("fa-2x");
    toclear.find('.showproxiescase').removeClass("fa-2x");

    setTimeout(function(){
        toclear.find('.proxiesdetail').empty();
        // toclear.find('.showproxiescase').empty();
    }, 1000);


})
