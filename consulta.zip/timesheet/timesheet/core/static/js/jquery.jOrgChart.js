/**
 * jQuery org-chart/tree plugin.
 *
 * Author: Wes Nolte
 * http://twitter.com/wesnolte
 *
 * Based on the work of Mark Lee
 * http://www.capricasoftware.co.uk
 *
 * Copyright (c) 2011 Wesley Nolte
 * Dual licensed under the MIT and GPL licenses.
 *
 */
(function($) {
    var cont = 1;
    var csrftoken = $.cookie('csrftoken');
  $.fn.jOrgChart = function(options) {
    var opts = $.extend({}, $.fn.jOrgChart.defaults, options);
    var $appendTo = $(opts.chartElement);
    // build the tree
    $this = $(this);
    var $container = $("<div class='" + opts.chartClass + "'/>");
    if($this.is("ul")) {
      buildNode($this.find("li:first"), $container, 0, opts);
    }
    else if($this.is("li")) {
      buildNode($this, $container, 0, opts);
    }
    $appendTo.append($container);

    // add drag and drop if enabled
    if(opts.dragAndDrop){
        $('div.node').draggable({
            cursor      : 'move',
            distance    : 40,
            helper      : 'clone',
            opacity     : 0.8,
            revert      : 'invalid',
            revertDuration : 100,
            snap        : 'div.node.expanded',
            snapMode    : 'inner',
            stack       : 'div.node'
        });

        $('div.node > div.a-tree').droppable({
            accept      : '.node,.li-person',
            activeClass : 'drag-active',
            hoverClass  : 'drop-hover'
        });

        var oldParentId;
      // Drag start event handler for nodes
      $('div.node').bind("dragstart", function handleDragStart( event, ui ){
            $(this).parentsUntil('.node-container').find('.node-container').find('.a-tree').each(function( index ) {
                $(this).droppable().droppable('disable');
            });
      });

    //   // Drag stop event handler for nodes
       $('div.node ').bind("dragstop", function handleDragStop( event, ui ){

           $(this).parentsUntil('.node-container').find('.node-container').find('.a-tree').each(function( index ) {
                   $(this).droppable().droppable("enable");
            });

       });

        var idsToUpdate = [];
        function getChildrens(pais){
            pais.children().each(function(){
                if($(this).find('.a-tree')[0]){
                    var element = $(this).find('.a-tree');
                    if(jQuery.inArray(element.attr('idelement'), idsToUpdate) !== -1){
                        //elemente aredy in
                    }else{
                        idsToUpdate.push(element.attr('idelement'));
                    }
                    getChildrens($(this));
                }
            });
        }

      // Drop event handler for nodes
      $('div.node').bind("drop", function handleDropEvent( event, ui ) {
            if(ui.draggable.attr('idperson')){
                if(cont == 1 ){
                    var dragPersonId = ui.draggable.attr('idperson');
                    if($(this).children().attr('idbox')){
                        if(proxyaddbox){
                          var dropBoxId = $(this).children().attr('idbox');
                          var durl = "/box/clonepersoninbox/"+dragPersonId+'/'+dropBoxId;
                          $.ajax({
                                type: "GET",
                                url: durl,
                                beforeSend: function(xhr, settings) {
                                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                                },
                                success: function(data){
                                    if(data == 0){
                                        toastr.warning('This person already exist here or the owner.');
                                    }else{
                                        $('.modal-title').html('Add Person');
                                        $('.modal-body').html(data);
                                        $('#myModal').modal('show');
                                        $('.cloneperson').attr("action", "/box/clonepersoninbox/"+dragPersonId+'/'+dropBoxId+'/');
                                        formProxyByAjax($('.modal-body').find('form'));

                                  }
                                }
                            });
                        }else{
                            toastr.warning("you don't have permission to move person in box");
                        }
                    }else if($(this).children().attr('idcase')){
                        if(proxyaddcase){
                            var dropCaseId = $(this).children().attr('idcase');
                            var durl = "/case/clonepersonincase/"+dragPersonId+'/'+dropCaseId;
                            $.ajax({
                                  type: "GET",
                                  url: durl,
                                  beforeSend: function(xhr, settings) {
                                    xhr.setRequestHeader("X-CSRFToken", csrftoken);
                                  },
                                  success: function(data){
                                      if(data == 0){
                                          toastr.warning('This person already exist here or the owner.');
                                      }else{
                                          $('.modal-title').html('Add Person');
                                          $('.modal-body').html(data);
                                          $('#myModal').modal('show');
                                          $('.cloneperson').attr("action", "/case/clonepersonincase/"+dragPersonId+'/'+dropCaseId+'/');
                                    }
                                  }
                              });
                        }else{
                            toastr.warning("you don't have permission to move person in case");
                        }
                    }
                }

            }else if(ui.draggable.children().attr('idbox')){
                if(cont == 1 ){
                    if(workaddwork){
                        var targetID = $(this).data("tree-node");
                        var targetLi = $this.find("li").filter(function() { return $(this).data("tree-node") === targetID; } );
                        var targetUl = targetLi.children('ul');

                        var sourceID = ui.draggable.data("tree-node");
                        var sourceLi = $this.find("li").filter(function() { return $(this).data("tree-node") === sourceID; } );
                        var sourceUl = sourceLi.parent('ul');

                        if (targetUl.length > 0){
                  		    targetUl.append(sourceLi);
                        } else {
                  		    targetLi.append("<ul></ul>");
                  		    targetLi.children('ul').append(sourceLi);
                        }

                        //Removes any empty lists
                        if (sourceUl.children().length === 0){
                          sourceUl.remove();
                        }

                        var parentId = $(this).children().attr('idbox');
                        var sonId = ui.draggable.children().attr('idbox');
                        var oldParentId = ui.draggable.parents("table").eq(1).children().children().first().children().children().children().attr('idbox');

                        // check if is new box
                        if(parentId){
                            if(oldParentId != parentId){
                                //UPDATE POSITION BOX
                                var durl = "/box/updatebox";
                                $.ajax({
                                    type: "POST",
                                    data: {
                                        'parentId' : parentId,
                                        'sonId' : sonId
                                    },
                                    url: durl,
                                    beforeSend: function(xhr, settings) {
                                      xhr.setRequestHeader("X-CSRFToken", csrftoken);
                                    },
                                    success: function(data){
                                        reloadboxes();
                                    }
                                });
                            }
                        }
                    }else{
                        toastr.warning("you don't have permission to move box");
                    }
                }

        }else if(ui.draggable.children().attr('idcase')){
            if(cont == 1){
                if(caseaddcase){
                    var targetID = $(this).data("tree-node");
                    var targetLi = $this.find("li").filter(function() { return $(this).data("tree-node") === targetID; } );
                    var targetUl = targetLi.children('ul');

                    var sourceID = ui.draggable.data("tree-node");
                    var sourceLi = $this.find("li").filter(function() { return $(this).data("tree-node") === sourceID; } );
                    var sourceUl = sourceLi.parent('ul');

                    if (targetUl.length > 0){
              		    targetUl.append(sourceLi);
                    } else {
              		    targetLi.append("<ul></ul>");
              		    targetLi.children('ul').append(sourceLi);
                    }

                    //Removes any empty lists
                    if (sourceUl.children().length === 0){
                      sourceUl.remove();
                    }

                    var casedrag = ui.draggable.children().attr('idcase');

                    idsToUpdate.push(casedrag);
                    getChildrens(ui.draggable.parent().parent().parent());

                    var boxdropid = $(this).children().attr('idbox');
                    var casedrop = $(this).children().attr('idcase');
                    var oldParentIdcase = ui.draggable.parents("table").eq(1).children().children().first().children().children().children().attr('idcase');

                    if(idsToUpdate){
                        if(oldParentIdcase != casedrop){
                            ////UPDATE POSITION CASE
                            var durl = "/case/updatecase";
                            setTimeout(function(){

                                $.ajax({
                                    type: "POST",
                                    data: {
                                        'idsToUpdate[]' : idsToUpdate,
                                        'boxdropid' : boxdropid,
                                        'casedrop' : casedrop
                                    },
                                    url: durl,
                                    beforeSend: function(xhr, settings) {
                                      xhr.setRequestHeader("X-CSRFToken", csrftoken);
                                    },
                                    success: function(data){

                                        var inbox = ((ui.draggable.parents('.casesnotinbox').length > 0) ? true : false) ;
                                        if(inbox){
                                            reloadcases();
                                        }else{
                                            ajaxGetCaseInBox(data.old);
                                            ajaxGetCaseInBox(data.new);
                                        }

                                        idsToUpdate = []
                                    }
                                });
                            },500);
                        }
                    }
                }else{
                    toastr.warning("you don't have permission to move case");
                }
            }
        }
        cont += 1;
        setTimeout(function(){
            cont = 1;
        },200);

      }); // handleDropEvent
    } // Drag and drop
  };

  // Option defaults
  $.fn.jOrgChart.defaults = {
    chartElement : 'body',
    depth      : -1,
    chartClass : "jOrgChart",
    dragAndDrop: false
  };

  var nodeCount = 0;
  // Method that recursively builds the tree
  function buildNode($node, $appendTo, level, opts) {
    var $table = $("<table cellpadding='0' cellspacing='0' border='0'/>");
    var $tbody = $("<tbody/>");

    // Construct the node container(s)
    var $nodeRow = $("<tr/>").addClass("node-cells");
    var $nodeCell = $("<td/>").addClass("node-cell").attr("colspan", 2);
    var $childNodes = $node.children("ul:first").children("li");
    var $nodeDiv;

    if($childNodes.length > 1) {
      $nodeCell.attr("colspan", $childNodes.length * 2);
    }
    // Draw the node
    // Get the contents - any markup except li and ul allowed
    var $nodeContent = $node.clone()
                            .children("ul,li")
                            .remove()
                            .end()
                            .html();

      //Increaments the node count which is used to link the source list and the org chart
  	nodeCount++;
  	$node.data("tree-node", nodeCount);
  	$nodeDiv = $("<div>").addClass("node")
                                     .data("tree-node", nodeCount)
                                     .append($nodeContent);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                    //////
//////                                          START BOX                                                 //////
//////                                                                                                    //////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function getFirstOfModal(){
        setTimeout(function(){
                $('.modal-body input')[1].focus()
        }
        , 400);
    }

    //ADD NEW BOX
    var newbox = $nodeDiv.children().children('div').children('div').children('.newbox');
    newbox.click(function() {
        id = $(this).attr('idbox');
        var durl = "/box/newbox/"+id;
        $.ajax({
            type: "GET",
            url: durl,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('.modal-title').html('New Box');
                $('.modal-body').html(data);
                $('#myModal').modal('show');
                $('.modalform').attr("action", '/box/newbox/'+id+'/');
                getFirstOfModal();
                formBoxByAjax($('.modal-body').find('form'));
            }
        });
    });

    ////EDIT BOX
    var edit = $nodeDiv.children().children('div').children('div').children('.edit');
    edit.click(function() {
        id = $(this).attr('idbox');
        $('#'+id).text();
        $('#myModal').modal('show');

          var durl = "/box/editbox/"+id;
          $.ajax({
              type: "GET",
              url: durl,
              beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
              },
              success: function(data){
                  $('.modal-title').html('Edit Box');
                  $('.modal-body').html(data);
                  $('#myModal').modal('show');
                  $('.modalform').attr("action", '/box/editbox/'+id+'/');
                  formBoxByAjax($('.modal-body').find('form'));
              }
          });
    });

    ////DELETE BOX
    var idsToDelete = [];
    function getChildrens(pais){
        pais.children().each(function(){
            if($(this).find('.li-tree')[0]){
                var element = $(this).find('.li-tree');
                if(jQuery.inArray(element.attr('id'), idsToDelete) !== -1){
                    //elemente aredy in
                }else{
                    idsToDelete.push(element.attr('id'));
                }
                getChildrens(element);
            }
        });
    }
    var deletebox = $nodeDiv.children().children('div').children('div').children('.deletebox');
    deletebox.click(function() {
        var r = confirm("Are you sure you want delete this box?");
        if (r == true) {
          var idbox = $(this).attr('idbox');

          idsToDelete.push(idbox);
          getChildrens($(this).parent());

          var durl = "/box/deletebox";
          $.ajax({
              type: "POST",
              data: {
                  'BoxidsToDelete[]' : idsToDelete,
              },
              url: durl,
              beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
              },
              success: function(data){
                  reloadboxes();
              }
          });
        }
    });

    //SHOW PERSONS IN BOX
    var timer;
    var showproxies = $nodeDiv.children().children('div').children('div').children('.showproxies');
    showproxies.mouseover(function() {
        if(!$(this).hasClass('fa-2x')){
            id = $(this).attr('idbox');
            showproxi = $(this);

            timer = setTimeout(function () {
                showproxi.addClass("fa-2x");
                $('.detailproxies'+id).fadeIn();
                $('.detailproxies'+id).removeClass('hidden');
                ajaxGetPersonsInBox(id)
            }, 200);
        }

    }).on("mouseleave", showproxies, function(){
        clearTimeout(timer);

    });


    //SHOW CASES IN BOX
    var showcases = $nodeDiv.children().children('div').children('div').children('.showcases');
    showcases.click(function() {
        id = $(this).attr('idbox');
        if($('.detailcases'+id).hasClass('hidden')){
          $('.detailcases'+id).removeClass('hidden');

          if(!$('.detailproxies'+id).hasClass('hidden')){
              $('.detailproxies'+id).addClass('hidden');
          }

          ajaxGetCaseInBox(id);

      }else{
        //   $('.detailcases'+id).html('');
          $('.detailcases'+id).addClass('hidden');
      }
    });

    //function to create a new proxy
    function newproxy(id){
      var durl = "/proxy/newproxy/"+id;
      $.ajax({
          type: "GET",
          url: durl,
          beforeSend: function(xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
          },
          success: function(data){
              $('.modal-title').html('Add Person');
              $('.modal-body').html(data);
              $('#myModal').modal('show');
              $('.modalform').attr("action", '/proxy/newproxy/'+id+'/');
              formProxyByAjax($('.modal-body').find('form'));
          }
      });
    }

    function formBoxByAjax(form){
        form.submit(function() {
            var data = form.serializeArray();
            var url = form.attr('action');
            $.ajax({
                type: "POST",
                data: data,
                url: url,
                beforeSend: function(xhr, settings) {
                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                },
                success: function(data){

                    $('#myModal').modal('hide');
                    reloadboxes();
                }
            });
            return false;
        });
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////                                                                                                    //////
    //////                                          END BOX JS                                                //////
    //////                                                                                                    //////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////                                                                                                    //////
    //////                                          START CASE                                                //////
    //////                                                                                                    //////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //ADD NEW CASE
    var newcase = $nodeDiv.children().children('div').children('div').children('.newcase');
    newcase.click(function() {

        var inbox = (($(this).parents('.casesnotinbox').length > 0) ? true : false) ;
        var idbox = $nodeDiv.parent().parent().parent().parent().parent().parent().attr('idbox');
        if(!idbox){
            idbox = "0";
        }
        id = $(this).attr('idcase');
        var durl = "/case/newcase/"+id+"/"+idbox;
        $.ajax({
            type: "GET",
            url: durl,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('.modal-title').html('New Case');
                $('.modal-body').html(data);
                $('#myModal').modal('show');
                $('.modalform').attr("action", '/case/newcase/'+id+'/'+idbox+'/');
                getFirstOfModal();
                formCaseByAjax($('.modal-body').find('form'), inbox);
            }
        });
    });
    function formCaseByAjax(form, inbox){
        form.submit(function() {
            var data = form.serializeArray();
            var url = form.attr('action');
            $.ajax({
                type: "POST",
                data: data,
                url: url,
                beforeSend: function(xhr, settings) {
                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                },
                success: function(data){
                    $('#myModal').modal('hide');
                    if(!inbox){
                        if(data.old){
                            ajaxGetCaseInBox(data.old)
                        }
                        if(data.new){
                            ajaxGetCaseInBox(data.new)
                        }
                    }else{
                        reloadcases();
                    }
                }
            });
            return false;
        });

    }

    function formProxyByAjaxForCase(form){
        form.submit(function() {
            var data = form.serializeArray();
            var url = form.attr('action');
            $.ajax({
                type: "POST",
                data: data,
                url: url,
                beforeSend: function(xhr, settings) {
                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                },
                success: function(data){
                    alert('teste');
                    $('#myModal').modal('hide');
                     ajaxGetProxyInBox(data);

                }
            });
            return false;
        });

    }

    var newcaseplus = $nodeDiv.children('.newcase');
    newcaseplus.click(function() {
        var idbox = $nodeDiv.parent().parent().parent().parent().parent().parent().attr('idbox');
        if(!idbox){
            idbox = "0";
        }
        id = $(this).attr('idcase');
        var durl = "/case/newcase/"+id+"/"+idbox;
        $.ajax({
            type: "GET",
            url: durl,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('.modal-title').html('New Case');
                $('.modal-body').html(data);
                $('#myModal').modal('show');
                $('.modalform').attr("action", '/case/newcase/'+id+'/'+idbox+'/');
                getFirstOfModal();
                formCaseByAjax($('.modal-body').find('form'));
            }
        });
    });

    var editnamecase = $nodeDiv.children().children('.editnamecase');
    editnamecase.on('click',function(){
        editnameofcase($(this),casename)
    });

    var idsToUpdate2 = [];
    function getChildrens2(pais){
        pais.children().each(function(){
            if($(this).find('.a-tree')[0]){
                var element = $(this).find('.a-tree');
                if(jQuery.inArray(element.attr('idelement'), idsToUpdate2) !== -1){
                    //elemente aredy in
                }else{
                    idsToUpdate2.push(element.attr('idelement'));
                }
                getChildrens2($(this));
            }
        });
    }

    ////EDIT NEW CASE
    var editcase = $nodeDiv.children().children('div').children('div').children('.editcase');
    editcase.click(function() {
        id = $(this).attr('idcase');
        var inbox = (($(this).parents('.casesnotinbox').length > 0) ? true : false) ;
        idsToUpdate2.push(id);
        getChildrens2($(this).parent().parent().parent().parent().parent().parent().parent());


        $('#'+id).text();
        $('#myModal').modal('show');
        var durl = "/case/editcase/"+id;
        $.ajax({
            type: "GET",
            url: durl,
            data:{
                'idsToUpdate[]': idsToUpdate2
            },
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                $('.modal-title').html('Edit Case');
                $('.modal-body').html(data);
                $('#myModal').modal('show');
                $('.modalform').attr("action", '/case/editcase/'+id+'/');
                formCaseByAjax($('.modal-body').find('form'), inbox);
            }
        });
    });

    var deletecase = $nodeDiv.children().children('div').children('div').children('.deletecase');
    deletecase.click(function() {
        //check are load in box or in separeted case
        var inbox = (($(this).parents('.casesnotinbox').length > 0) ? true : false) ;
        var r = confirm("Are you sure you want delete this case?");
        if (r == true) {
          var idcase = $(this).attr('idcase');

          idsToDelete.push(idcase);
          getChildrens($(this).parent());

          var durl = "/case/deletecase";
          $.ajax({
              type: "POST",
              data: {
                  'CaseidsToDelete[]' : idsToDelete,
              },
              url: durl,
              beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
              },
              success: function(data){
                  if(!inbox){
                      ajaxGetCaseInBox(data)
                  }else{
                      reloadcases();
                  }
              }
          });
        }

    });

    //SHOW PERSONS IN BOX
    var showproxiescase = $nodeDiv.children().children('div').children('div').children('.showproxiescase');
    showproxiescase.mouseover(function() {
        if(!$(this).hasClass('fa-2x')){
            id = $(this).attr('idcase');
            showproxi = $(this);

            timer = setTimeout(function () {
                showproxi.addClass("fa-2x");
                $('.detailproxiescase'+id, $(document)).removeClass('hidden');
                $('.detailproxiescase'+id).fadeIn('');
                 ajaxGetProxyInBox(id)
            }, 200);
        }

    }).on("mouseleave", showproxiescase, function(){
        clearTimeout(timer);

    });


    function ajaxGetProxyInBox(id){
        var durl = "/case/getPersonsInCase/"+id;
        $.ajax({
            type: "GET",
            url: durl,
            beforeSend: function(xhr, settings) {
              xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function(data){
                  if(data){
                      var thishtml = $.parseHTML(data);

                      $('.delete-person-of-case', $(thishtml)).on('click', function(){
                          deletepersonofcase($(this).attr('idcase'), $(this).attr('idperson'));
                      });

                      $('.editcase', $(thishtml)).on('click', function(){
                          editproxycase($(this).attr('idproxy'), proxyeditcase);
                      });

                      $('.newproxycase', $(thishtml)).on('click', function(){
                          if($(this).children().attr('idcase')){
                              newproxycase($(this).children().attr('idcase'));
                          }
                      });

                      var originalcontent = "";
                      $('.searchproxycase',$(thishtml)).keyup(function(){
                          var idcase = $(this).attr('idcase');
                          var searchPersonContent = $(this).val();
                          if(originalcontent == ""){
                               originalcontent = $('.list-proxy-person'+idcase).html();
                          }
                          if(searchPersonContent.length > 2){
                              //ajax search person in proxy
                              var durl = "/person/searchpersoninproxy";
                              $.ajax({
                                  type: "POST",
                                  data: {
                                      'type': 'case',
                                      'id' : idcase,
                                      'searchPersonContent' : searchPersonContent,
                                  },
                                  url: durl,
                                  beforeSend: function(xhr, settings) {
                                    xhr.setRequestHeader("X-CSRFToken", csrftoken);
                                  },
                                  success: function(data){

                                      var thishtml = $.parseHTML(data);

                                      $('.delete-person-of-case', $(thishtml)).on('click', function(){
                                          deletepersonofcase($(this).attr('idcase'), $(this).attr('idperson'));
                                      });

                                      $('.editcase', $(thishtml)).on('click', function(){
                                          editproxycase($(this).attr('idproxy'), proxyeditcase);
                                      });

                                      $('.newproxycase', $(thishtml)).on('click', function(){
                                          if($(this).children().attr('idcase')){
                                              newproxycase($(this).children().attr('idcase'));
                                          }
                                      });

                                      $('.list-proxy-person'+idcase).html(thishtml);
                                  }
                              });

                          }else{
                              $('.list-proxy-person'+idcase).html(originalcontent);
                          }
                      });

                      ////trigger mouse start
                      var oldMouseStart = $.ui.draggable.prototype._mouseStart;
                      $.ui.draggable.prototype._mouseStart = function (event, overrideHandle, noActivation) {
                          this._trigger("beforeStart", event, this._uiHash());
                          oldMouseStart.apply(this, [event, overrideHandle, noActivation]);
                      };
                      $('.li-person', $(thishtml)).draggable({
                          cursor      : 'move',
                          distance    : 40,
                          helper      : 'clone',
                          opacity     : 0.8,
                          revert      : 'invalid',
                          revertDuration : 100,
                          snap        : 'div.node.expanded',
                          snapMode    : 'inner',
                          stack       : 'div.node'
                      });

                      $('.detailproxiescase'+id).html(thishtml);
                  }
            }
        });

    }

    //function to delete person of proxy
    function deletepersonofcase(idcase, idperson){

      var r = confirm("Are you sure you want delete this person ?");
      if (r == true) {
          var durl = "/case/deletepersonofcase/"+idcase+'/'+idperson;
          $.ajax({
              type: "GET",
              url: durl,
              beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
              },
              success: function(data){
                   ajaxGetProxyInBox(data);
              }
          });
      }
    }

    //function to create a new proxy
    function newproxycase(id){
      var durl = "/proxy/newproxycase/"+id;
      $.ajax({
          type: "GET",
          url: durl,
          beforeSend: function(xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
          },
          success: function(data){
              $('.modal-title').html('Add Person');
              $('.modal-body').html(data);
              $('#myModal').modal('show');
              $('.modalform').attr("action", '/proxy/newproxycase/'+id+'/');
              formProxyByAjaxForCase($('.modal-body').find('form'));
          }
      });
    }


    function editproxycase(id, proxyeditcase){
        if(proxyeditcase){
            var durl = "/proxy/editproxycase/"+id;
            $.ajax({
                type: "GET",
                url: durl,
                beforeSend: function(xhr, settings) {
                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                },
                success: function(data){
                    $('.modal-title').html('Edit Persons');
                    $('.modal-body').html(data);
                    $('#myModal').modal('show');
                    $('.modalform').attr("action", '/proxy/editproxycase/'+id+'/');
                    formProxyByAjaxForCase($('.modal-body').find('form'));
                }
            });
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                    //////
//////                                          END CASE JS                                               //////
//////                                                                                                    //////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                    //////
//////                                          START WORK JS                                             //////
//////                                                                                                    //////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    var nodeoriginalwidth;
    var originalnode;
    var showworks = $nodeDiv.children().children('div').children('div').children('.showworks');
    showworks.on('click', function(){
        console.log($('.bigline', $(document)));
        id = $(this).attr('idcase');
        if($('.worksdetail'+id).hasClass('hidden')){

            $('.worksdetail'+id).removeClass('hidden');

            if(!$('.detailproxiescase'+id).hasClass('hidden')){
                $('.detailproxiescase'+id).addClass('hidden');
            }

            var durl = "/work/getworks/"+id;
            $.ajax({
                type: "GET",
                url: durl,
                beforeSend: function(xhr, settings) {
                  xhr.setRequestHeader("X-CSRFToken", csrftoken);
                },
                success: function(data){
                    if(data){
                        var thishtml = $.parseHTML(data);
                        //used to remove work of case
                        if(workdeletework){
                            $('.remove-work-of-case', $(thishtml)).on('click', function(){
                                removework($(this).attr('idwork'), $(this));
                            });
                        }

                        //used to add new work
                        if(workaddwork){
                            $('.addnew', $(thishtml)).on('click',function(){
                                //save new work with creator and creationDate
                                var firstdescription = $($(this).parent().children('table').children('tbody').children().first().children()[1]).text();
                                var hastr = $(this).parent().children('table').children('tbody').children().first().children()
                                if(hastr.length != 0){
                                    if(firstdescription ){
                                        addnewwork(id);
                                    }else{
                                        alert('you alredy created a new one');
                                    }
                                }else{
                                    addnewwork(id);
                                }
                            });
                        }

                        if(workeditwork){
                            //used to update field elements in work table.
                            $('.inputelement', $(thishtml)).on('click',function(){
                                if($(this).hasClass('inputelement')){
                                    updateWorkTableField($(this));
                                }
                            });
                        }

                        $('.input-work-search', $(thishtml)).on('keyup',function(){
                            ajaxSearchWork($(this));
                        });

                        //function to show all works in specific case
                        var showall = false;
                        $('.showallworks', $(thishtml)).on('click', function(){
                            showall = showallworks($(this),showall);
                        });

                        $('.worksdetail'+id).html(thishtml);
                        $('.worksdetail'+id).width(1000);

                        ////function to limit length of tr in cases
                        worklimitlength();
                    }
                }
            });

        }else{
            $('.worksdetail'+id).addClass('hidden');
        }
    });

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                    //////
//////                                          END WORK JS                                               //////
//////                                                                                                    //////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Expand and contract nodes
    if ($childNodes.length > 0) {
      var minimize = $nodeDiv.children().children('div').children('div').children('.minimize');
      minimize.click(function() {

          var $this = $(this);
          var $tr = $this.closest("tr");

          if($tr.hasClass('contracted')){
            $this.removeClass('glyphicon glyphicon-chevron-down');
            $this.addClass('glyphicon glyphicon-chevron-up');

            $tr.removeClass('contracted').addClass('expanded');
            $tr.nextAll("tr").css('visibility', '');

            // Update the <li> appropriately so that if the tree redraws collapsed/non-collapsed nodes
            // maintain their appearance
            $node.removeClass('collapsed');
          }else{
            $this.removeClass('glyphicon glyphicon-chevron-up');
            $this.addClass('glyphicon glyphicon-chevron-down');
            $tr.removeClass('expanded').addClass('contracted');
            $tr.nextAll("tr").css('visibility', 'hidden');

            $node.addClass('collapsed');
          }
        });
    }

    $nodeCell.append($nodeDiv);
    $nodeRow.append($nodeCell);
    $tbody.append($nodeRow);

    if($childNodes.length > 0) {
      // recurse until leaves found (-1) or to the level specified
      if(opts.depth == -1 || (level+1 < opts.depth)) {
        var $downLineRow = $("<tr/>");
        var $downLineCell = $("<td/>").attr("colspan", $childNodes.length*2);
        $downLineRow.append($downLineCell);

        // draw the connecting line from the parent node to the horizontal line
        $downLine = $("<div></div>").addClass("line down");
        $downLineCell.append($downLine);
        $tbody.append($downLineRow);

        // Draw the horizontal lines
        var $linesRow = $("<tr/>");
        $childNodes.each(function() {
          var $left = $("<td>&nbsp;</td>").addClass("line left top");
          var $right = $("<td>&nbsp;</td>").addClass("line right top");
          $linesRow.append($left).append($right);
        });

        // horizontal line shouldn't extend beyond the first and last child branches
        $linesRow.find("td:first")
                    .removeClass("top")
                 .end()
                 .find("td:last")
                    .removeClass("top");

        $tbody.append($linesRow);
        var $childNodesRow = $("<tr/>");
        $childNodes.each(function() {
           var $td = $("<td class='node-container'/>");
           $td.attr("colspan", 2);
           // recurse through children lists and items
           buildNode($(this), $td, level+1, opts);
           $childNodesRow.append($td);
        });

      }
      $tbody.append($childNodesRow);
  }else{
      var minimize = $nodeDiv.children().children('div').children('div').children('.minimize');
       minimize.removeClass('glyphicon glyphicon-chevron-up');
  }

    // any classes on the LI element get copied to the relevant node in the tree
    // apart from the special 'collapsed' class, which collapses the sub-tree at this point
    if ($node.attr('class') != undefined) {
        var classList = $node.attr('class').split(/\s+/);
        $.each(classList, function(index,item) {
            if (item == 'collapsed') {
                $nodeRow.nextAll('tr').css('visibility', 'hidden');
                    $nodeRow.removeClass('expanded');
                    $nodeRow.addClass('contracted');
            } else {
                $nodeDiv.addClass(item);
            }
        });
    }

    $table.append($tbody);
    $appendTo.append($table);

    /* Prevent trees collapsing if a link inside a node is clicked */
    $nodeDiv.children('a').click(function(e){
        e.stopPropagation();
    });
  };

})(jQuery);
