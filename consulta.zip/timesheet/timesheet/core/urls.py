from django.conf.urls import url, include
from django.contrib.auth import views as auth_views
from box.views import listbox

urlpatterns = [
    url(r'^$', listbox, name='home'),
    url(r'^box', include('box.urls', namespace='box')),
    url(r'^proxy', include('proxy.urls', namespace='proxy')),
    url(r'^person', include('person.urls', namespace='person')),
    url(r'^case', include('case.urls', namespace='case')),
    url(r'^work', include('work.urls', namespace='work')),
    url(r'^tax', include('tax.urls', namespace='tax')),
    url(r'^invoice', include('invoice.urls', namespace='invoice')),
    url(r'^bank', include('bank.urls', namespace='bank')),
    url(r'^expense', include('expense.urls', namespace='expense')),
    url(r'^operation', include('operation.urls', namespace='operation')),
    url(r'^context', include('context.urls', namespace='context')),
    url(r'^customer', include('customer.urls', namespace='customer')),
    url(r'^login/$', auth_views.login, {'template_name': 'login.html'},name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': '/'}, name='logout'),

]
