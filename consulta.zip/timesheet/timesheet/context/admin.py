from django.contrib import admin
from .models import Context
# Register your models here.

admin.site.register(Context)