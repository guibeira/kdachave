from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse_lazy
from bank.forms import BankContextForm
from bank.models import Bank
from bank.models import getbankbycontext
from django.views.generic.edit import CreateView, UpdateView, DeleteView
# Create your views here.

def createBankAccount(request):
    getbankbycontext(request.user)
    if request.method == "POST":
        form = BankContextForm(request.POST)
        if form.is_valid():
            bank = form.save(commit=False)
            bank.save()
            return redirect('context:listbank')
        else:
            return render(request, 'modalform.html', {'form': form})
    else:
        form = BankContextForm()
        return render(request, 'context/form_bank.html', {'form': form})

def listaccountbank(request):
    accounts = getbankbycontext(request.user)
    context = {
        'accounts' : accounts
    }
    return render(request, 'context/list.html', context)

class DeleteBank(DeleteView):
    model = Bank
    success_url = reverse_lazy('context:listbank')
    template_name = 'confirmdelete.html'

class UpdateBank(UpdateView):
    
    model = Bank
    form_class = BankContextForm
    template_name = 'context/form_bank.html'
    success_url = reverse_lazy('context:listbank')
