from django.db import models

# Create your models here.

class Context(models.Model):
    contextname = models.CharField(max_length=100)
    description = models.TextField()
    # logo = models.ImageField(upload_to='uploads/logos/')
    email = models.EmailField()
    person = models.ManyToManyField('person.Person')

    def __str__(self):
        return self.contextname