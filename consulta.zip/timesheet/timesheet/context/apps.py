from django.apps import AppConfig


class ContextConfig(AppConfig):
    name = 'context'
