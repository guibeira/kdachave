from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^/listtaxes$', views.listtaxes, name='listtaxes'),
    url(r'^/gettaxestowork$', views.gettaxestowork, name='gettaxestowork'),
    url(r'^/addtax$', views.addtax, name='addtax'),
    url(r'^/updatetax$', views.updatetax, name='updatetax'),
    url(r'^/searchtax$', views.searchtax, name='searchtax'),
    url(r'^/deletetax/(?P<idtax>[0-9]+)/$', views.deletetax, name = 'deletetax'),

]
