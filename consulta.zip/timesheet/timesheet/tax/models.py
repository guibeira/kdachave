from django.db import models
# Create your models here.


class Tax(models.Model):
    name = models.CharField(max_length=100)
    percentage = models.FloatField()
    description = models.TextField()

    class Meta:
        permissions = (
            ("show_tax", "Can show Taxes"),
            )

    def __str__(self):
        return self.name
