from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
# Models
from .models import Tax

# Forms
from .forms import TaxForm
from django.contrib.auth.decorators import permission_required


@permission_required('tax.show_tax')
def listtaxes(request):
    taxes = Tax.objects.all()
    context = {'taxes': taxes}
    return render(request, 'tax/getalltaxes.html', context)


@permission_required('tax.add_tax')
def addtax(request):
    if request.method == "POST":
        form = TaxForm(request.POST)
        if form.is_valid():
            tax = form.save(commit=False)
            tax.save()
            return redirect('tax:listtaxes')
        else:
            return render(request, 'modalform.html', {'form': form})

    form = TaxForm()
    return render(request, 'modalform.html', {'form': form})


@permission_required('tax.delete_tax')
def deletetax(request, idtax):
    tax = get_object_or_404(Tax, pk=idtax)
    tax.delete()
    return redirect('tax:listtaxes')


@permission_required('tax.change_tax')
def updatetax(request):

    if request.method == 'POST':
        idtax = request.POST.get('idtax')
        fieldtype = request.POST.get('fieldtype')
        newcontent = request.POST.get('newcontent')
        tax = get_object_or_404(Tax, pk=idtax)

        tax.__dict__[str(fieldtype)] = newcontent

        tax.save()

        return HttpResponse(200)


def searchtax(request):
    if request.method == 'POST':
        searchContent = request.POST.get('searchContent')
        taxes = Tax.objects.filter(name__contains=searchContent) | Tax.objects.filter(description__contains=searchContent)
        context = {'taxes': taxes}
        return render(request, 'tax/resultsearchtax.html', context)


def gettaxestowork(request):
    taxes = Tax.objects.all()
    l = []
    for tax in taxes:
        taxesdict = {"id": tax.pk,
                     "name": tax.name,
                     "percentage": tax.percentage}
        l.append(taxesdict)

    return JsonResponse(l, safe=False)
