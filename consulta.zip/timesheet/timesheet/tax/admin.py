from django.contrib import admin
from .models import Tax
# Register your models here.

admin.site.register(Tax)
