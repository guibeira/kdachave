from django.db.models.signals import pre_save, pre_delete, post_save
from django.dispatch import receiver
from django.conf import settings
from .models import Bank
from operation.models import Operation, OperationStatus
import os.path




@receiver(pre_save, sender=Bank)
@receiver(pre_save, sender=Bank)
def model_pre_change(sender, **kwargs):
    if os.path.isfile(settings.READ_ONLY_FILE):
        raise ReadOnlyException('Model in read only mode, cannot save')



@receiver(post_save, sender=Bank)
def model_post_save(sender, **kwargs):
    print('no signal do bank')
    print(kwargs['instance'])
    if kwargs['created']:
        Operation.objects.create(correntvalue=0, operationvalue=0, operationresult=0, bank=kwargs['instance'] )
                   


class ReadOnlyException(Exception):
    pass
