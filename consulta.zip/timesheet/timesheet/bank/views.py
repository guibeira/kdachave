from django.shortcuts import render
from django.core.urlresolvers import reverse_lazy
from .models import Bank
from .forms import  BankForm
from django.views.generic.edit import CreateView, UpdateView, DeleteView

# Create your views here.


def index(request):
    banks = Bank.objects.all()

    context = {
        'banks' : banks
    }
    return render(request, 'bank/list.html', context)


class BankCreate(CreateView):
    model = Bank
    fields = ['bankname','bankagencyname', 'accountnumber', 'iban', 'accountDesignation']
    success_url = reverse_lazy('bank:home')

class DeleteBank(DeleteView):
    model = Bank
    success_url = reverse_lazy('bank:home')
    template_name = 'confirmdelete.html'

class UpdateBank(UpdateView):
    
    model = Bank
    form_class = BankForm
    template_name = 'bank/bank_form.html'
    success_url = reverse_lazy('bank:home')

  