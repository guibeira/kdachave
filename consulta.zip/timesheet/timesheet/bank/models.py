from django.db import models
from context.models import  Context
# Create your models here.
class Bank(models.Model):

    bankname = models.CharField(max_length=100)
    bankagencyname = models.CharField(max_length=100, null=True, blank=True)
    accountnumber = models.CharField(max_length=100, null=True, blank=True)
    iban = models.CharField(max_length=100, null=True, blank=True)
    accountDesignation = models.ForeignKey('customer.Customer', null=True)
    contextDesignation = models.ForeignKey('context.Context', null=True)

    def __str__(self):
        return self.bankname

def getbankbycontext(user):
    contexts = Context.objects.filter(person=user.person)
    for context in contexts:
        account = Bank.objects.filter(contextDesignation=context)
    return account