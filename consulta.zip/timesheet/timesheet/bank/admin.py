from django.contrib import admin
from .models import Bank
# Register your models here.
admin.site.register(Bank)