from django.conf.urls import url
from . import views

urlpatterns = [

    # url(r'^/newcase/(?P<parentId>[0-9]+)/$', views.newcase, name='newcase'),
    url(r'^/$', views.index, name='home'),
    url(r'^/create/$', views.BankCreate.as_view(), name='create'),
    url(r'^/deletebank/(?P<pk>[0-9]+)/$', views.DeleteBank.as_view(), name='delete'),
    url(r'^update/(?P<pk>[0-9]+)$', views.UpdateBank.as_view(), name='update'),

]