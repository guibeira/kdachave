from django.db import models
from djmoney.models.fields import MoneyField
from django.core.validators import MaxValueValidator, MinValueValidator

# Create your models here.
class Invoice(models.Model):

    CREDIT = 'credit'
    DEBIT = 'debit'
    MODALITY_CHOICES = (
       (DEBIT, 'Debit'),
        (CREDIT, 'Credit'),
    )
    title = models.CharField(max_length=200)
    work = models.ManyToManyField('work.Work',null=True, blank=True)
    modality = models.CharField(max_length=10, choices=MODALITY_CHOICES)
    vat = models.ForeignKey('tax.Tax')
    invoicetype= models.ForeignKey('InvoiceType')
    responsible = models.ForeignKey('person.Person')
    receiver = models.ForeignKey('bank.Bank', related_name='bankreceiver')
    recipient = models.ForeignKey('bank.Bank', related_name='bankrecipient')
    paid = models.BooleanField(default=False)
    datepaid = models.DateField(null=True, blank=True)
    expiration_date  = models.DateField(null=True, blank=True)
    amount = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    amounttax = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    amoutManual = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    amountDiscount = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    
    

    def __str__(self):
        return '{}, {}'.format(self.title, self.recipient)
    
class InvoiceType(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Installment(models.Model):

    value = MoneyField(decimal_places=2, max_digits=8, null=True, blank=True, default_currency='BRL')
    expiration_date  = models.DateField()
    number  = models.PositiveIntegerField(null=True)
    invoice = models.ForeignKey('Invoice', null=True)
    paid = models.BooleanField(default=False)
    datepaid = models.DateField(null=True, blank=True)

    def __str__(self):
        return '{} / {}'.format(self.invoice, self.number)
