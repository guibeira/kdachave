from django.contrib import admin
from .models import Invoice, InvoiceType, Installment
# Register your models here.

admin.site.register(Invoice)
admin.site.register(InvoiceType)
