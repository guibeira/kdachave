from django.shortcuts import render , redirect, get_object_or_404
from django.core.urlresolvers import reverse_lazy
from django.urls import reverse
from .models import Invoice, Installment
from django.http import HttpResponse, JsonResponse
from .forms import InvoiceForm, InstallmentForm
from expense.models import Expense
from django.views.generic import DeleteView, DetailView
from datetime import datetime, timezone
now = datetime.now(timezone.utc)

def index(request):
    
    invoiceslate = Invoice.objects.filter(expiration_date__lte= now).filter(paid=False)
    invoicesPaid = Invoice.objects.filter(paid=True)
    invoicesToExpire= Invoice.objects.filter(expiration_date__gte=now)
    print(invoiceslate)
    context = {
        'invoiceslate' : invoiceslate,
        'invoicesPaid' : invoicesPaid,
        'invoicesToExpire' : invoicesToExpire
    }
    return render(request, 'invoice/list.html', context)


def createInvoice(request):
    
    form = InvoiceForm(request)
    if request.method == 'POST':
        form = InvoiceForm(request, request.POST)
        expenses = request.POST.getlist('expense')
        choicesexpenses = []
        choicesinstallment = []
        for ex in expenses:
            choicesexpenses.append((ex,ex))
        form.fields['expense'].choices = choicesexpenses
        if form.is_valid():
            works = form.cleaned_data['work']
            expenses = form.cleaned_data['expense']
            invoice = form.save(commit=False)
            invoice.save()
            total = [work.pricePerunit for work in works]
            amount = 0
            for epe in expenses:
                expense = get_object_or_404(Expense, pk=epe)
                expense.invoice = invoice
                amount += expense.amount
                expense.save()
            for i in total:
                amount += i
            invoice.amount = amount
            invoice.amounttax = (float(amount.amount)+(invoice.vat.percentage*float(amount.amount)/100))-float(amount.amount)
            invoice.work = works
            invoice.save()
            return redirect('invoice:detail', pk=invoice.pk)
        else:
            return render(request, 'invoice/form.html', {'form': form})
    else:
        return render(request, 'invoice/form.html',  {'form': form})


def createInstallment(request):

    if request.is_ajax():
        if request.method == "GET":
            form = InstallmentForm()
            return render(request, 'modalform.html', {'form': form})
        if request.method == "POST":

            form = InstallmentForm(data=request.POST)

            if form.is_valid():
                installment = form.save(commit=False)
                installment.save()
                return JsonResponse({'date': installment.expiration_date, 'value': str(installment.value), 'pk': installment.pk })

            else:
                print(form.errors)
                return HttpResponse(status=500)


class DeleteInvoice(DeleteView):
    model = Invoice
    success_url = reverse_lazy('invoice:home')
    template_name = 'confirmdelete.html'

class DetailInvoice(DetailView):

    model = Invoice
    template_name = 'invoice/detail.html'

    def get_context_data(self, **kwargs):
        context = super(DetailInvoice, self).get_context_data(**kwargs)
       
        context['expenses'] = Expense.objects.filter(invoice__pk=self.kwargs['pk'])
        return context

