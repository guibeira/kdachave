from django import forms
from .models import Invoice , Installment
from bank.models import getbankbycontext

class InvoiceForm(forms.ModelForm):
    
    expense = forms.MultipleChoiceField(required=False)
    delaydate = forms.IntegerField(min_value=0, max_value=120)

    def __init__(self, request, *args, **kwargs):
        super(InvoiceForm, self).__init__(*args, **kwargs)
        if request.user:
            send = []
            for bank in getbankbycontext(request.user):
                send.append((bank.pk, bank))
            self.fields['receiver'].choices = send

    class Meta:

        model = Invoice
        fields = ( 'title','invoicetype', 'receiver', 'recipient', 'work', 'vat', 'modality', 'responsible',)

class InstallmentForm(forms.ModelForm):

    class Meta:
        model = Installment
        fields = ('value', 'expiration_date',)