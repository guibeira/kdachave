from django.conf.urls import url
from . import views

urlpatterns = [

    # url(r'^/newcase/(?P<parentId>[0-9]+)/$', views.newcase, name='newcase'),
    url(r'^/$', views.index, name='home'),
    url(r'^/create/$',views.createInvoice, name='create'),
    url(r'^/createinstallment/$', views.createInstallment , name='createinstallment'),
    url(r'^/delete/(?P<pk>[0-9]+)/$', views.DeleteInvoice.as_view(), name='delete'),
    url(r'^/detail/(?P<pk>[0-9]+)/$', views.DetailInvoice.as_view(), name='detail'),

]