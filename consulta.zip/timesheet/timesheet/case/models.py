from django.db import models
from person.models import Person
from proxy.models import Proxy
from work.models import Work
from box.models import listBoxesForAjax
from datetime import datetime, timezone
# Create your models here.

now = datetime.now(timezone.utc)


class Case(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    creationDate = models.DateTimeField(auto_now_add=True)
    box = models.ForeignKey('box.Box')
    parent = models.ForeignKey('case.Case', null=True, blank=True)
    owner = models.ForeignKey('person.Person')
    customer = models.ManyToManyField('customer.Customer', blank=True)
    work = models.ManyToManyField('work.Work', blank=True)
    lastupadate = models.DateTimeField(null=True, blank=True)

    class Meta:
        permissions = (
            ("show_person", "Can show Pesons"),
            ("show_work", "Can show Works"),
            )

    def __str__(self):
        return self.name


def getAllCasesbyUser(request, user):
    boxes = []
    proxies = []
    listcase = []
    listproxy = []
    list_comparator = []
    base = []
    d = {}
    nothaveson =[]
    repeted = []

    ## get logged user
    user = Person.objects.get(user=user)

    #get all the proxy for make comparatorcase
    comparatorcase = []
    proxx = Proxy.objects.exclude(creator=user)
    for i in proxx:
        if(i.case):
            comparatorcase.append(i.case)
            checkHasSon(i.case, user, comparatorcase)

	#convert elements in list
    proxylistcase = []
    repeted = []

    caseproxy_comparator = converterdicinlist(comparatorcase, proxylistcase)
    if(Proxy.objects.filter(person=request.user.person)):
        for proxy in Proxy.objects.filter(person=request.user.person):
            if proxy.box:
                if(Case.objects.filter(box=proxy.box)):
                    for casefbox in Case.objects.filter(box=proxy.box):
                        base.append(casefbox)

    listboxes = listBoxesForAjax(request.user)
    allboxes = converterdicinlist(listboxes, [])
    for box in allboxes:
        if(Case.objects.filter(box=box)):
            for casefbox in Case.objects.filter(box=box):
                if casefbox not in base:
                    base.append(casefbox)

	## get direct Cases of user
    if(Case.objects.filter(owner=user)):
        for case in Case.objects.filter(owner=user):
			##check if this element aready exits to dont show again
            if(case.parent not in caseproxy_comparator ):
                d = {case: []}
				##check if has son, and append in boxes
                if(Case.objects.filter(parent=case)):
                    for sons in Case.objects.filter(parent=case):
                        d[case].append(sons)
                        if d not in boxes:
                            boxes.append(d)
                        checkHasSon(sons, user, boxes)
                else:
					##if he dont have sons, append in separeted list
					# boxes.append(d)
                    if case not in base:
                        base.append(case)
    else:
        listcase = []
		## make the dict of father with son inside

    if (len(boxes) > 1):
        listcase = []
        for num in range(len(boxes)):
			##get father
            comparator = boxes[num]
            for k, v in comparator.items():
				## get elements of boxes to compare with father
                for i in boxes:
                    for key, val in i.items():
						## if father is the element, dont compare
                        if (key != k):
                            for x in range(len(v)):
								#check if son inside list
                                if key == v[x]:
                                    comparator[k][x] = i
									#Add element as child
                                    if comparator not in listcase:
                                        listcase.append(comparator)
									#Adds element to list to prevent repetition
                                    if i not in repeted:
                                        repeted.append(i)
                                else:
                                    if (i not in nothaveson) and (i not in listcase):
                                        nothaveson.append(i)

    elif len(listcase) < 1 and len(boxes) <= 1:
        listcase = boxes
	#If elements do not have children
    if (len(listcase) < 1):
        listcase = list(boxes)

	#remove from base repeted itens
    listresult = []
    base_comparator_box = converterdicinlist(listcase,listresult)

	#creat comparator on base comparator
    comparator_proxy = []

    for  i in base_comparator_box:
        if str(i) not in comparator_proxy:
            comparator_proxy.append(str(i))

	# add elements of not have sons
    for x in range(len(nothaveson)):
        if  ( str(list(nothaveson[x].keys())[0]) not in comparator_proxy ) and  (nothaveson[x] not in listcase):
            listcase.append(nothaveson[x])

	#create new list to remove in base
    newlistresults = []
    new_case_comparator = converterdicinlist(listcase,newlistresults)

	##remove from base repeted itens
    for i in new_case_comparator:
        for x in base:
            if i == x:
                base.remove(x)

	#add iten in listcase
    for i in base:
        if i not in listcase:
            listcase.append(i)

	#Removes repeated elements
    for x in repeted:
        for i in listcase:
            if x==i:
                listcase.remove(x)
	# get proxies ralated to logged user
    base_proxy = []
    for proxy in Proxy.objects.filter(person=user).filter(startDate__lte=now):
        if(proxy.endDate == None or proxy.endDate >= now):
            if proxy.case:
                if(proxy.case.parent not in caseproxy_comparator ):
                    d = {proxy.case: []}
                    if(Case.objects.filter(parent=proxy.case)):
                        for sons in Case.objects.filter(parent=proxy.case):
                            d[proxy.case].append(sons)
                            if d not in proxies:
                                proxies.append(d)
                            checkHasSon(sons, user, proxies)
                    else:
                        listproxy.append(proxy.case)
                        base_proxy.append(proxy.case)
                else:
                    if(proxy.case.parent not in caseproxy_comparator ):
                        listproxy.append(proxy.case)
                        base_proxy.append(proxy.case)

    repeted_proxy = []
    ## check if proxies has value

    if (len(proxies) > 0):
        listproxy = []
		## get dict to compare with other elements
        for num in range(len(proxies)):
            comparator = proxies[num]
            ## get key, value of comparator elements
            for k, v in comparator.items():
                ## get element of proxies
                for i in proxies:
                    ##get key, value of proxies item
                    for key, val in i.items():
                        ## check if comparator key is diferent of proxies item key
                        if (key != k):
                            ## check elements values of proxies
                            for x in range(len(v)):
                                ## check if proxie item key is equal of comparator value in element value position
                                if key == v[x]:
                                    comparator[k][x] = i
                                    if comparator not in listproxy:
                                        listproxy.append(comparator)
                                    if i not in repeted_proxy:
                                        repeted_proxy.append(i)
                        else:
                            if i not in listproxy:
                                list_comparator.append(i)
                                listproxy.append(i)


    if len(listproxy) <= 1 and len(proxies) <= 1:
        listproxy = proxies
		## create base list to compare if other proxies are in original list
        base_list = []
        if(len(listproxy) > 0):

            if(type(listproxy[0]) == type(dict())):
                temporary_list = []

                for key, val in listproxy[0].items():
                    if type(val) == type(list()):
                        if key not in base_list:
                            base_list.append(key)
                        for x in range(len(val)):
                            if type(val[x]) == type(dict()):
                                ledic(val[x],base_list)
                            else:
                                if val[x] not in base_list:
                                    base_list.append(val[x])
                    else:
                        if val not in base_list:
                            base_list.append(val)


	            ##check if other proxies are in original list
                for x in range(len(list_comparator)):

                    val = list(list_comparator[x])
                    if val[0] not in base_list:
                        temporary_list = list(listproxy[0].values())
                        temporary_list[0].append(list_comparator[x])
	                    ## prevent the sons of sons that aren't in original list be add one more time
                        if type(list(list_comparator[x].values())[0][0]) == type(dict()):
                            base_list.append(list(list(list_comparator[x].values())[0][0].keys())[0])

	            ## add value of new proxy into original list
                if len(temporary_list) > 0:
                    keylistproxy = list(listproxy[0].keys())
                    listproxy[0][keylistproxy[0]] = temporary_list[0]

    for i in repeted_proxy:
        for x in listproxy:
            if i==x:
                listproxy.remove(x)

	#create list based in the new listproxy for check if proxys without sons aready in listproxy
    listresultproxy = []
    base_comparator_proxy = converterdicinlist(listproxy,listresultproxy)

    for i in base_proxy:
        if i not in base_comparator_proxy:
            listproxy.append(i)

    comparator_proxy = []
    for  i in base_comparator_box:
        comparator_proxy.append(str(i))

    temporary_list_box = []
    for x in range(len(listproxy)):
        if( type(listproxy[x]) == type(list()) ):
            val = str(list(list_comparator[x])[0])
        elif( type(listproxy[x]) == type(dict()) ):
            val = list(listproxy[x])
            val = str(val[0])
        else:
            val = str(listproxy[x])

        if val not in comparator_proxy:
            if listproxy[x] not in temporary_list_box:
                temporary_list_box.append(listproxy[x])
                if(type(listproxy[x]) == type(dict())):
                    if(len(list(listproxy[x].values())[0]) > 0):
                        if(type(list(listproxy[x].values())[0][0]) == type(dict())):
                            comparator_proxy.append(str(list(list(listproxy[x].values())[0][0].keys())[0]))
                            if(len(list(list(listproxy[x].values())[0][0].values())[0]) > 0 ):
                                var = (list(list(listproxy[x].values())[0][0].values())[0][0])
                                if(type(var) == type(dict())):
                                    if(len(list(var.values())[0]) > 0):
                                        read(var,comparator_proxy)
                                    else:
                                        comparator_proxy.append(str(list(var.keys())[0]))

                                elif(type(val) == type(str())):
                                    comparator_proxy.append(str(var))
                                else:
                                    comparator_proxy.append(str(list(var)[0]))
                else:
                    comparator_proxy.append(listproxy[x])

    for i in comparator_proxy:
        for num in temporary_list_box:
            if(type(num) == type(dict())):
                if( str(list(num.keys())[0]) == i ):
                    temporary_list_box.remove(num)


    if len(temporary_list_box) > 0:
        if (len(listcase) > 0):
            if(type(listcase[0]) == type(dict())):
                keylistbox = list(listcase[0].keys())
                for i in range(len(temporary_list_box)):
                    if temporary_list_box[i] not in listcase:
                        listcase.append(temporary_list_box[i])
            else:
                for i in range(len(temporary_list_box)):
                    if temporary_list_box[i] not in listcase:
                        listcase.append(temporary_list_box[i])
        else:
			#if person dont have box, but have only proxy
            listcase = listproxy
            
    ## return
    listcase = converterdicinlist(listcase,[])
    if listcase:
        return listcase
    else:
        return []


def checkHasSon(value, user, boxes):

	if(Case.objects.filter(parent=value)):
		d = {value: []}
		for box in Case.objects.filter(parent=value):
			d[value].append(box)
			if d not in boxes:
				boxes.append(d)
			checkHasSon(box,user,boxes)


def converterdicinlist(di, listresult):

    if type(di) == type(dict()):
        for c, v in di.items():

            if type(v) == type(list()):
                listresult.append(c)
                for x in range(len(v)):
                    if type(v[x]) == type(dict()):
                        converterdicinlist(v[x],listresult)
                    else:
                        listresult.append(v[x])
            else:
                listresult.append(c)

                listresult.append(v)
    elif(type(di) == type(list())):

        for x in range(len(di)):

            if type(di[x]) == type(dict()):
                converterdicinlist(di[x],listresult)
            else:
                listresult.append(di[x])
            tracim = ''
    else:
        listresult.append(di)

    return(listresult)


def updateTimeCaseByWork(id):
    now = datetime.now(timezone.utc)
    work = Work.objects.get(pk=id)
    cases = Case.objects.filter(work=work)
    for case in cases:
        case.lastupadate = now
        case.save()
