from django import template
from django.template import Context, Template

register = template.Library()
varhtml = ''
context = {}


def ledic(di, user):
    case_add = user.has_perm('case.add_case')
    case_edit = user.has_perm('case.change_case')
    case_delete = user.has_perm('case.delete_case')
    case_show_person = user.has_perm('case.show_person')
    case_show_works = user.has_perm('case.show_work')
    global varhtml
    global context
    for c, v in di.items():
        if type(v) == type(list()):
            ## is parent
            varhtml += '<li class="li-tree casesdetail" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamecase" idcase="{}" nameelement="{}">{}</div> <span class="owner-name">{}</span> </br>\n'.format(c.pk,c.pk,c.pk,c.name.lower(), c.pk, c, c, c.owner)
            varhtml += '<div class="box-icons">\n'
            varhtml += '<div class="box-icons-top">\n'
            if case_add:
                varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus"  data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(c.pk)
            if case_edit:
                varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true" ></i>\n'.format(c.pk)
            if case_delete:
                varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true" ></i>\n'.format(c.pk)
            varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="box-icons-down">\n'
            if case_show_works:
                varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(c.pk)
            if case_show_person:
                varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="proxiesdetail detailproxiescase{} hidden"></div>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(c.pk)
            varhtml += '<ul class="ul-tree drag">\n'

            if(len(v)== 0):

                varhtml += '</ul>\n'
                varhtml += '</li>\n'

            else:
                for x in range(len(v)):
                    if type(v[x]) == type(dict()):
                        # varhtml += 'LEDIC 1 {}\n'.format(v[x])
                        ledic(v[x], user)

                        total = v[x].values()
                        if x+1 == len(v):
                            for i in range(len(total)):
                                varhtml += '</ul>\n'
                                varhtml += '</li>\n'
                    else:
                        ## is son
                        varhtml += '<li class="li-tree casesdetail" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamecase" idcase="{}" nameelement="{}">{}</div> <span class="owner-name">{}</span> </br>\n'.format(v[x].pk,v[x].pk,v[x].pk, v[x].name.lower(), v[x].pk, v[x], v[x], v[x].owner)
                        varhtml += '<div class="box-icons">\n'
                        varhtml += '<div class="box-icons-top">\n'
                        if case_add:
                            varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus" data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(v[x].pk)
                        if case_edit:
                            varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(v[x].pk)
                        if case_delete:
                            varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n'.format(v[x].pk)
                        varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="box-icons-down">\n'
                        if case_show_works:
                            varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works" ></i>\n'.format(v[x].pk)
                        if case_show_person:
                            varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(v[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="proxiesdetail detailproxiescase{} hidden">\n'.format(v[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '<div class="worksdetail worksdetail{} hidden"></div><ul class="ul-tree drag"></ul></li>\n'.format(v[x].pk)
                        if x+1 == len(v):
                            varhtml += '</ul>\n'
                            varhtml += '</li>\n'

        else:
            ## is parent
            varhtml += '<li class="li-tree casesdetail" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamecase" idcase="{}" nameelement="{}">{}</div><span class="owner-name">{}</span> </br>\n'.format(c.pk,c.pk,c.pk, c.name.lower(), c.pk, c, c, c.owner)
            varhtml += '<div class="box-icons">\n'
            varhtml += '<div class="box-icons-top">\n'
            if case_add:
                varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus" data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(c.pk)
            if case_edit:
                varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" aria-hidden="true" data-toggle="tooltip" title="edit"></i>\n'.format(c.pk)
            if case_delete:
                varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n'.format(c.pk)
            varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="box-icons-down">\n'
            if case_show_works:
                varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(c.pk)
            if case_show_person:
                varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="proxiesdetail detailproxiescase{} hidden"></div>\n'.format(c.pk)
            varhtml += '</div>\n'
            varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(c.pk)
            varhtml += '<ul class="ul-tree drag">\n'
            ## is son
            varhtml += '<li class="li-tree casesdetail" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree"><div class="editnamecase" idcase="{}" nameelement="{}">{}</div> <span class="owner-name">{}</span> </br>\n'.format(v.pk,v.pk,v.pk, v.name.lower(),v.pk,v, v, v.owner)
            varhtml += '<div cl ass="box-icons">\n'
            varhtml += '<div class="box-icons-top">\n'
            if case_add:
                varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus" data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(v.pk)
            if case_edit:
                varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(v.pk)
            if case_delete:
                varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i> \n'.format(v.pk)
            varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="box-icons-down">\n'
            if case_show_works:
                varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(v.pk)
            if case_show_person:
                varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(v.pk)
            varhtml += '</div>\n'
            varhtml += '</div>\n'
            varhtml += '<div class="proxiesdetail detailproxiescase{} hidden"></div>\n'.format(v.pk)
            varhtml += '</div>\n'
            varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(v.pk)
            varhtml += '</li>\n'
            varhtml += '</ul>\n'
            varhtml += '</li>\n'

def calllediccase(value, user):
    print(value);
    case_add = user.has_perm('case.add_case')
    case_edit = user.has_perm('case.change_case')
    case_delete = user.has_perm('case.delete_case')
    case_show_person = user.has_perm('case.show_person')
    case_show_works = user.has_perm('case.show_work')

    global varhtml
    global context
    value = [value]
    auxvarhtml = ''
    if(type(value[0]) == type(dict())):
        for key, val in value[0].items():
            ## check if have son
            if type(val) == type(list()):

                if len(val) >1:
                    last = val[-1]
                else:
                    last = val
                ## is parent
                varhtml += '<li  class="home li-tree casesdetail" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamecase" idcase="{}" nameelement="{}">{}</div> <span class="owner-name">{}</span> </br>\n'.format(key.pk,key.pk,key.pk, key.name.lower(), key.pk, key, key, key.owner)
                varhtml += '<div class="box-icons">\n'
                varhtml += '<div class="box-icons-top">\n'
                if case_add:
                    varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus"data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(key.pk)
                if case_edit:
                    varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(key.pk)
                if case_delete:
                    varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i> \n'.format(key.pk)
                varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="box-icons-down">\n'
                if case_show_works:
                    varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(key.pk)
                if case_show_person:
                    varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(key.pk)
                varhtml += '</div>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="proxiesdetail detailproxiescase{}"></div>\n'.format(key.pk)
                varhtml += '</div>\n'
                varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(key.pk)
                varhtml += '<ul>\n'

                if(len(val)< 1):
                    varhtml += '</ul>\n'
                    varhtml += '</li>\n'
                for x in range(len(val)):
                    if type(val[x]) == type(dict()):
                        ledic(val[x], user)
                        total = val[x].values()
                        if x+1 == len(val):
                            for i in range(len(total)):
                                varhtml += '</ul>\n'
                                varhtml += '</li>\n'
                    else:
                        varhtml += '<li class="li-tree casesdetail"  ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamecase" idcase="{}" nameelement="{}">{}</div><span class=" owner-name">{}</span> </br>\n'.format(val[x].pk,val[x].pk,val[x].pk, val[x].name.lower(), val[x].pk, val[x], val[x], val[x].owner)
                        varhtml += '<div class="box-icons">\n'
                        varhtml += '<div class="box-icons-top">\n'
                        if case_add:
                            varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus" data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(val[x].pk)
                        if case_edit:
                            varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(val[x].pk)
                        if case_delete:
                            varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n' .format(val[x].pk)
                        varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="box-icons-down">\n'
                        if case_show_works:
                            varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(val[x].pk)
                        if case_show_person:
                            varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(val[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '</div>\n'
                        varhtml += '<div class="proxiesdetail detailproxiescase{} hidden"></div>\n'.format(val[x].pk)
                        varhtml += '</div>\n'
                        varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(val[x].pk)
                        varhtml += '</li>\n'

                        if x+1 == len(val):
                            varhtml += '</ul>\n'
                            varhtml += '</li>\n'

            else:
                varhtml += '<li class="li-tree casesdetail" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree"><div class="editnamecase" idcase="{}" nameelement="{}">{}</div> <span class=" owner-name">{}</span> </br>\n'.format(val.pk,val.pk,val.pk, val.name.lower(), val.pk, val, val, val.owner)
                varhtml += '<div class="box-icons">\n'
                varhtml += '<div class="box-icons-top">\n'
                if case_add:
                    varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus" data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(val.pk)
                if case_edit:
                    varhtml += '<i idcase= {} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i>\n'.format(val.pk)
                if case_delete:
                    varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i> \n'.format(val.pk)
                varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="box-icons-down">\n'
                if case_show_works:
                    varhtml += '<i idcase= {} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(val.pk)
                if case_show_person:
                    varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(val.pk)
                varhtml += '</div>\n'
                varhtml += '</div>\n'
                varhtml += '<div class="proxiesdetail detailproxiescase{} hidden"></div>\n'.format(val.pk)
                varhtml += '</div>\n'
                varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(val[x].pk)
                varhtml += '</li>\n'

        ret = printHtml(varhtml, context)
        varhtml = ''
        return ret

    else:
        varhtml += '<li class="li-tree  casesdetail home" home="home" ><div idelement="{}" idcase="{}" id="b-{}" nameelement="{}" class="a-tree" ><div class="editnamecase" idcase="{}" nameelement="{}">{}</div> <span  class="owner-name">{}</span> </br>\n'.format(value[0].pk,value[0].pk,value[0].pk, value[0].name.lower(),value[0].pk, value[0], value[0], value[0].owner)
        varhtml += '<div class="box-icons">\n'
        varhtml += '<div class="box-icons-top">\n'
        if case_add:
            varhtml += '<i idcase={} class="newcase glyphicon glyphicon-plus" data-toggle="tooltip" title="add new case" aria-hidden="true"></i>\n'.format(value[0].pk)
        if case_edit:
            varhtml += '<i idcase={} class="editcase fa fa-pencil-square-o" data-toggle="tooltip" title="edit" aria-hidden="true"></i> \n'.format(value[0].pk)
        if case_delete:
            varhtml += '<i idcase={} class="deletecase glyphicon glyphicon-remove" data-toggle="tooltip" title="remove" aria-hidden="true"></i>\n'.format(value[0].pk)
        varhtml += '<i class="minimize glyphicon glyphicon-chevron-up" aria-hidden="true"></i>\n'
        varhtml += '</div>\n'
        varhtml += '<div class="box-icons-down">\n'
        if case_show_works:
            varhtml += '<i idcase={} class="showworks fa fa-briefcase" data-toggle="tooltip" title="show works"></i>\n'.format(value[0].pk)
        if case_show_person:
            varhtml += '<i idcase= {} class="showproxiescase fa fa-user" data-toggle="tooltip" title="show persons"></i>\n'.format(value[0].pk)
        varhtml += '</div>\n'
        varhtml += '</div>\n'
        varhtml += '<div class="proxiesdetail detailproxiescase{} hidden"></div>\n'.format(value[0].pk)
        varhtml += '</div>\n'
        varhtml += '<div class="worksdetail worksdetail{} hidden"></div>\n'.format(value[0].pk)
        varhtml += '</li>\n'

        ret = printHtml(varhtml, context)
        varhtml = ''
        return ret

def printHtml(varhtml, context):

    t = Template(varhtml)
    c = Context(context)
    html = t.render(c)
    varhtml = ''
    return html

register.filter('calllediccase', calllediccase)
