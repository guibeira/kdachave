from django.contrib import admin
from .models import Case
# Register your models here.


@admin.register(Case)
class CaseAdmin(admin.ModelAdmin):
    list_display = ('name', 'lastupadate',)
    list_filter = ('name', 'owner', 'customer', 'parent')
    search_fields = ['name']
