from django.apps import AppConfig


class CaseConfig(AppConfig):
    name = 'case'

    def ready(self):
        import case.signals
