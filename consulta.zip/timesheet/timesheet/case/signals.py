from django.db.models.signals import pre_save, pre_delete, post_save
from django.dispatch import receiver
from django.conf import settings
from .models import Case, updateTimeCaseByWork
from work.models import Work
import os.path


@receiver(pre_delete, sender=Work)
@receiver(pre_delete, sender=Case)
@receiver(pre_save, sender=Work)
@receiver(pre_save, sender=Case)
def model_pre_change(sender, **kwargs):
    if os.path.isfile(settings.READ_ONLY_FILE):
        raise ReadOnlyException('Model in read only mode, cannot save')


@receiver(post_save, sender=Work)
def model_post_save(sender, **kwargs):

    updateTimeCaseByWork(kwargs['instance'].__dict__['id'])


class ReadOnlyException(Exception):
    pass
