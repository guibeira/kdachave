from django.shortcuts import render, redirect, get_object_or_404
from datetime import datetime, timezone
from django.http import HttpResponse, JsonResponse
# Permissions
from django.contrib.auth.decorators import login_required, permission_required
# Models
from .models import Case
from proxy.models import Proxy
from person.models import Person
from box.models import Box
# Forms
from case.forms import CaseForm, EditCaseForm
from proxy.forms import ClonePersonInCaseForm
from box.views import listBoxesForAjax

now = datetime.now(timezone.utc)


@permission_required('case.change_case')
def editnamecase(request):
	if request.method == 'POST':
		idcase = request.POST.get('idcase')
		case = get_object_or_404(Case, pk=idcase)
		name = request.POST.get('namecase')
		case.name = name
		case.save()
		return HttpResponse(200)


def checkHasSon(value, user, boxes):

	if(Case.objects.filter(parent=value)):
		d = {value: []}
		for box in Case.objects.filter(parent=value):
			d[value].append(box)
			if d not in boxes:
				boxes.append(d)
			checkHasSon(box, user, boxes)


@permission_required('case.add_case')
def newcase(request, parentId="0", idbox="0"):

	if request.method == 'POST':
		form = CaseForm(request.POST)

		if(parentId != "0"):
			obj_parent = get_object_or_404(Case, pk=parentId)
		else:
			obj_parent = None

		if(idbox != "0"):
			box = get_object_or_404(Box, pk=idbox)
		else:
			box = obj_parent.box

		if form.is_valid():
			# box = get_object_or_404(Box, pk=form.cleaned_data['box'])
			case = form.save(commit=False)
			case.owner = request.user.person
			case.parent = obj_parent
			case.box = box
			case.lastupadate = now
			case.save()
			casestoreturn = {'new': case.box.pk}

			return JsonResponse(casestoreturn)
	else:
		form = CaseForm()
	return render(request, 'modalform.html', {'form': form})


@permission_required('case.change_case')
def editcase(request, id):

	case = get_object_or_404(Case, pk=id)
	proxies = Proxy.objects.filter(case=case).filter(startDate__lte=now)
	listperson = []
	for proxy in proxies:
		for p in proxy.person.all():
			if(p not in listperson):
				listperson.append(p)

	t = '';
	if(request.GET.getlist('idsToUpdate[]')):
		idsToUpdate = request.GET.getlist('idsToUpdate[]')
		for i in range(len(idsToUpdate)):
			if (i == (len(idsToUpdate) - 1)):
				t += str(idsToUpdate[i])
			else:
				t += str(idsToUpdate[i])+','

	if request.method == 'POST':
		form = EditCaseForm(request, listperson, request.POST)
		if form.is_valid():
			sons = form.cleaned_data['idsToUpdate']
			box = get_object_or_404(Box, pk=form.cleaned_data['box'])
			owner = get_object_or_404(Person, pk=form.cleaned_data['owner'])
			# caseform = form.save(commit=case)
			caseform = case
			if(case.box != box):
				caseform.parent = None
			oldbox = caseform.box
			caseform.box = box

			caseform.owner = owner
			caseform.save()
			for i in sons.split(','):
				caseaux = get_object_or_404(Case, pk=int(i))
				caseaux.box = caseform.box
				caseaux.save()
			boxestoreturn = {'new': box.pk,
							'old': oldbox.pk}

			return JsonResponse(boxestoreturn)
		else:
			return render(request, 'modalform.html', {'form': form})
	else:
		form = EditCaseForm(request, listperson, initial = {'idsToUpdate' : t, 'box':case.box.pk , 'owner':case.owner.pk})

	return render(request, 'modalform.html', {'form': form})


@permission_required('case.delete_case')
def delete(request):

	CaseidsToDelete = request.POST.getlist('CaseidsToDelete[]')
	for caseId in reversed(CaseidsToDelete):
		case = get_object_or_404(Case, pk=caseId)
		boxid = case.box.pk
		case.delete()
	return HttpResponse(boxid)


@permission_required('case.change_case')
def update(request):

	if request.method == 'POST':
		if(request.POST.getlist('idsToUpdate[]')):
			idsToUpdate = request.POST.getlist('idsToUpdate[]')
			for x in range(len(idsToUpdate)):
				case = get_object_or_404(Case, pk=idsToUpdate[x])
				oldbox = case.box
				if(request.POST.get('boxdropid')):
					box = get_object_or_404(Box, pk=int(request.POST.get('boxdropid')))
					case.box = box
					if x == 0:
						case.parent = None

				if(request.POST.get('casedrop')):
					casedrop = get_object_or_404(Case, pk=int(request.POST.get('casedrop')))
					case.box = casedrop.box
					if x == 0:
						case.parent = casedrop
				case.save()
			boxestoreturn = {'new': case.box.pk,
						'old': oldbox.pk}

		return JsonResponse(boxestoreturn)


@permission_required('case.show_person')
def getPersonsInCase(request, idcase):
	case = get_object_or_404(Case, pk=idcase)
	proxies = Proxy.objects.filter(case=case)
	listperson = []
	for proxy in proxies:
		for p in proxy.person.all():
			if(p not in listperson):
				d = {p:[proxy.startDate, proxy.endDate, proxy.id]}
				listperson.append(d)
	context = {
		'persons' : listperson,
		'case' : case,
		'now' : now,
	}

	return render(request, 'case/detailPersoninCase.html', context)


@permission_required('proxy.remove_person_case')
def deletepersonofcase(request, idcase, idperson):

	case = get_object_or_404(Case, pk=idcase)
	person = get_object_or_404(Person, pk=idperson)
	proxies = Proxy.objects.filter(person=person).filter(case=case)
	for p in proxies:
		p.person.remove(person)
		if p.person.count() == 0:
			p.delete()

	return HttpResponse(case.pk)


@permission_required('proxy.add_person_case')
def clonepersonincase(request, iddragperson, idcase):

	case = get_object_or_404(Case, pk=idcase)
	person = get_object_or_404(Person, pk=iddragperson)
	proxies = Proxy.objects.filter(person=person).filter(case=case)
	if(case.owner == person):
		return HttpResponse(0)
	if(proxies):
		return HttpResponse(0)

	if request.method == 'POST':
		form = ClonePersonInCaseForm(request.POST)
		obj_parent = get_object_or_404(Case, pk=idcase)
		if form.is_valid():
			proxy = form.save(commit=False)
			proxy.creator = request.user.person
			proxy.case = obj_parent
			proxy.save()
			proxy.person.add(person)
			proxy.save()
			return redirect('home')

	else:
		form = ClonePersonInCaseForm()
	return render(request, 'formcloneperson.html', {'form': form})

@login_required
def listcase(request, box):

	boxes = []
	listcase = []
	list_comparator = []
	base = []
	d = {}
	nothaveson =[]
	repeted = []

    ## get logged user
	user = Person.objects.get(user=request.user)

	#get all the proxy for make comparatorcase
	comparatorcase = []
	proxx = Proxy.objects.exclude(creator=user)
	for i in proxx:
		if(i.case):
			comparatorcase.append(i.case)
			checkHasSon(i.case, user, comparatorcase)

	#convert elements in list
	proxylistcase = []
	repeted = []
	caseproxy_comparator = converterdicinlist(comparatorcase,proxylistcase)

	## get direct Cases of user
	if(Case.objects.filter(box=box)):
		for case in Case.objects.filter(box=box):
			##check if this element aready exits to dont show again
			if(case.parent not in caseproxy_comparator ):
				d = {case: []}
				##check if has son, and append in boxes
				if(Case.objects.filter(parent=case)):
					for sons in Case.objects.filter(parent=case):
						d[case].append(sons)
						if d not in boxes:
							boxes.append(d)
						checkHasSon(sons, user, boxes)
				else:
					##if he dont have sons, append in separeted list
					# boxes.append(d)
					base.append(case)
	else:
		listcase = []
		## make the dict of father with son inside

	if (len(boxes) > 1):
		listcase = []
		for num in range(len(boxes)):
			##get father
			comparator = boxes[num]
			for k, v in comparator.items():
				## get elements of boxes to compare with father
				for i in boxes:
					for key, val in i.items():
						## if father is the element, dont compare
						if (key != k):
							for x in range(len(v)):
								#check if son inside list
								if key == v[x]:
									comparator[k][x] = i
									#Add element as child
									if comparator not in listcase:
										listcase.append(comparator)
									#Adds element to list to prevent repetition
									if i not in repeted:
										repeted.append(i)
								else:
									if (i not in nothaveson) and (i not in listcase):
										nothaveson.append(i)

	elif len(listcase) < 1 and len(boxes) <= 1:
		listcase = boxes
	#If elements do not have children
	if (len(listcase) < 1):
		listcase = list(boxes)

	#remove from base repeted itens
	listresult = []
	base_comparator_box = converterdicinlist(listcase,listresult)

	#creat comparator on base comparator
	comparator_proxy = []

	for  i in base_comparator_box:
		if str(i) not in comparator_proxy:
			comparator_proxy.append(str(i))

	# add elements of not have sons
	for x in range(len(nothaveson)):
		if  ( str(list(nothaveson[x].keys())[0]) not in comparator_proxy ) and  (nothaveson[x] not in listcase):
			listcase.append(nothaveson[x])

	#create new list to remove in base
	newlistresults = []
	new_case_comparator = converterdicinlist(listcase,newlistresults)

	##remove from base repeted itens
	for i in new_case_comparator:
		for x in base:
			if i == x:
				base.remove(x)

	#add iten in listcase
	for i in base:
		if i not in listcase:
			listcase.append(i)

	#Removes repeated elements
	for x in repeted:
		for i in listcase:
			if x==i:
				listcase.remove(x)

	if listcase:
		return listcase
	else:
		return []


def converterdicinlist(di,listresult):

    if type(di) == type(dict()):
        for c, v in di.items():

            if type(v) == type(list()):
                listresult.append(c)
                for x in range(len(v)):
                    if type(v[x]) == type(dict()):
                        converterdicinlist(v[x],listresult)
                    else:
                        listresult.append(v[x])
            else:
                listresult.append(c)

                listresult.append(v)
    elif(type(di) == type(list())):

        for x in range(len(di)):

            if type(di[x]) == type(dict()):
                converterdicinlist(di[x],listresult)
            else:
                listresult.append(di[x])
            tracim = ''
    else:
        listresult.append(di)

    return(listresult)


def read(var, comparator_proxy):

	if(type(var) == type(dict())):

		comparator_proxy.append(str(list(var.keys())[0]))
		if(len(list(var.values())[0]) > 0):
			if(type(list(var.values())[0][0]) ==  type(dict())):
				if(len(list(var.values())[0][0])>0):
					read(list(var.values())[0][0],comparator_proxy)
			else:
				comparator_proxy.append(str(list(var.values())[0][0]))
	else:
		comparator_proxy.append(str(var))

def loadcases(request):
	user = request.user
	boxes = listBoxesForAjax(user.pk)
	listboxes = converterdicinlist(boxes, [])
	cases = getCaseRemoveBox(request, listboxes)
	context = {'cases': cases}
	return render(request, 'case/listcasebyajax.html', context)

@login_required
def getCaseRemoveBox(request, boxcheck):
	boxes = []
	proxies = []
	listcase = []
	listproxy = []
	list_comparator = []
	base = []
	d = {}
	nothaveson =[]
	repeted = []

    ## get logged user
	user = Person.objects.get(user=request.user)

	#get all the proxy for make comparatorcase
	comparatorcase = []
	proxx = Proxy.objects.exclude(creator=user)
	for i in proxx:
		if(i.case):
			comparatorcase.append(i.case)
			checkHasSon(i.case, user, comparatorcase)

	#convert elements in list
	proxylistcase = []
	repeted = []
	caseproxy_comparator = converterdicinlist(comparatorcase,proxylistcase)

	## get direct Cases of user
	if(Case.objects.filter(owner=user)):
		for case in Case.objects.filter(owner=user):
			##check if this element aready exits to dont show again
			if(case.parent not in caseproxy_comparator ) and (case.box not in boxcheck):
				d = {case: []}
				##check if has son, and append in boxes
				if(Case.objects.filter(parent=case)):
					for sons in Case.objects.filter(parent=case):
						d[case].append(sons)
						if d not in boxes:
							boxes.append(d)
						checkHasSon(sons, user, boxes)
				else:
					##if he dont have sons, append in separeted list
					# boxes.append(d)
					base.append(case)
	else:
		listcase = []
		## make the dict of father with son inside

	if (len(boxes) > 1):
		listcase = []
		for num in range(len(boxes)):
			##get father
			comparator = boxes[num]
			for k, v in comparator.items():
				## get elements of boxes to compare with father
				for i in boxes:
					for key, val in i.items():
						## if father is the element, dont compare
						if (key != k):
							for x in range(len(v)):
								#check if son inside list
								if key == v[x]:
									comparator[k][x] = i
									#Add element as child
									if comparator not in listcase:
										listcase.append(comparator)
									#Adds element to list to prevent repetition
									if i not in repeted:
										repeted.append(i)
								else:

									if (i not in nothaveson) and (i not in listcase):
										nothaveson.append(i)

	elif len(listcase) < 1 and len(boxes) <= 1:
		listcase = boxes
	#If elements do not have children
	if (len(listcase) < 1):
		listcase = list(boxes)

	#remove from base repeted itens
	listresult = []
	base_comparator_box = converterdicinlist(listcase,listresult)

	#creat comparator on base comparator
	comparator_proxy = []

	for  i in base_comparator_box:
		if str(i) not in comparator_proxy:
			comparator_proxy.append(str(i))

	# add elements of not have sons
	for x in range(len(nothaveson)):
		if  ( str(list(nothaveson[x].keys())[0]) not in comparator_proxy ) and  (nothaveson[x] not in listcase):
			listcase.append(nothaveson[x])

	#create new list to remove in base
	newlistresults = []
	new_case_comparator = converterdicinlist(listcase,newlistresults)

	##remove from base repeted itens
	for i in new_case_comparator:
		for x in base:
			if i == x:
				base.remove(x)

	#add iten in listcase
	for i in base:
		if i not in listcase:
			listcase.append(i)

	#Removes repeated elements
	for x in repeted:
		for i in listcase:
			if x==i:
				listcase.remove(x)

	# get proxies ralated to logged user
	base_proxy = []
	for proxy in Proxy.objects.filter(person=user).filter(startDate__lte=now):
		if(proxy.endDate == None or proxy.endDate >= now):
			if proxy.case:
				if(proxy.case.parent not in caseproxy_comparator ) and (proxy.case.box not in boxcheck):
					d = {proxy.case: []}
					if(Case.objects.filter(parent=proxy.case)):
						for sons in Case.objects.filter(parent=proxy.case):
							d[proxy.case].append(sons)
							if d not in proxies:
								proxies.append(d)
							checkHasSon(sons, user, proxies)
					else:
						listproxy.append(proxy.case)
						base_proxy.append(proxy.case)
				else:
					if(proxy.case.parent not in caseproxy_comparator ) and (proxy.case.box not in boxcheck):
						listproxy.append(proxy.case)
						base_proxy.append(proxy.case)

	repeted_proxy = []
    ## check if proxies has value

	if (len(proxies) > 0):
		listproxy = []
		## get dict to compare with other elements
		for num in range(len(proxies)):
			comparator = proxies[num]
            ## get key, value of comparator elements
			for k, v in comparator.items():
                ## get element of proxies
				for i in proxies:
                    ##get key, value of proxies item
					for key, val in i.items():
                        ## check if comparator key is diferent of proxies item key
						if (key != k):
                            ## check elements values of proxies
							for x in range(len(v)):
                                ## check if proxie item key is equal of comparator value in element value position
								if key == v[x]:
									comparator[k][x] = i
									if comparator not in listproxy:
										listproxy.append(comparator)
									if i not in repeted_proxy:
										repeted_proxy.append(i)
						else:

							if i not in listproxy:
								list_comparator.append(i)
								listproxy.append(i)

    ###########################
	if len(listproxy) <= 1 and len(proxies) <= 1:
		listproxy = proxies
		## create base list to compare if other proxies are in original list
		base_list = []
		if(len(listproxy) > 0):

			if(type(listproxy[0]) == type(dict())):
				temporary_list = []

				for key, val in listproxy[0].items():
					if type(val) == type(list()):
						if key not in base_list:
							base_list.append(key)
						for x in range(len(val)):
							if type(val[x]) == type(dict()):
								ledic(val[x],base_list)
							else:
								if val[x] not in base_list:
									base_list.append(val[x])
					else:
						if val not in base_list:
							base_list.append(val)


	            ##check if other proxies are in original list
				for x in range(len(list_comparator)):

					val = list(list_comparator[x])
					if val[0] not in base_list:
						temporary_list = list(listproxy[0].values())
						temporary_list[0].append(list_comparator[x])
	                    ## prevent the sons of sons that aren't in original list be add one more time
						if type(list(list_comparator[x].values())[0][0]) == type(dict()):
							base_list.append(list(list(list_comparator[x].values())[0][0].keys())[0])


	            ## add value of new proxy into original list
				if len(temporary_list) > 0:
					keylistproxy = list(listproxy[0].keys())
					listproxy[0][keylistproxy[0]] = temporary_list[0]

     ###########################

	for i in repeted_proxy:
		for x in listproxy:
			if i==x:
				listproxy.remove(x)

	#create list based in the new listproxy for check if proxys without sons aready in listproxy
	listresultproxy = []
	base_comparator_proxy = converterdicinlist(listproxy,listresultproxy)

	for i in base_proxy:
		if i not in base_comparator_proxy:
			listproxy.append(i)

	comparator_proxy = []
	for  i in base_comparator_box:
		comparator_proxy.append(str(i))

	temporary_list_box = []
	for x in range(len(listproxy)):
		if( type(listproxy[x]) == type(list()) ):
			val = str(list(list_comparator[x])[0])
		elif( type(listproxy[x]) == type(dict()) ):
			val = list(listproxy[x])
			val = str(val[0])
		else:
			val = str(listproxy[x])

		if val not in comparator_proxy:
			if listproxy[x] not in temporary_list_box:
				temporary_list_box.append(listproxy[x])
				if(type(listproxy[x]) == type(dict())):
					if(len(list(listproxy[x].values())[0]) > 0):
						if(type(list(listproxy[x].values())[0][0]) == type(dict())):
							comparator_proxy.append(str(list(list(listproxy[x].values())[0][0].keys())[0]))
							if(len(list(list(listproxy[x].values())[0][0].values())[0]) > 0 ):
								var = (list(list(listproxy[x].values())[0][0].values())[0][0])
								if(type(var) == type(dict())):
									if(len(list(var.values())[0]) > 0):
										read(var,comparator_proxy)
									else:
										comparator_proxy.append(str(list(var.keys())[0]))

								elif(type(val) == type(str())):
									comparator_proxy.append(str(var))
								else:
									comparator_proxy.append(str(list(var)[0]))
				else:
					comparator_proxy.append(listproxy[x])


	for i in comparator_proxy:
		for num in temporary_list_box:
			if(type(num) == type(dict())):
				if( str(list(num.keys())[0]) == i ):
					temporary_list_box.remove(num)


	if len(temporary_list_box) > 0:
		if (len(listcase) > 0):
			if(type(listcase[0]) == type(dict())):
				keylistbox = list(listcase[0].keys())
				for i in range(len(temporary_list_box)):
					listcase.append(temporary_list_box[i])
			else:
				for i in range(len(temporary_list_box)):
					listcase.append(temporary_list_box[i])
		else:
			#if person dont have box, but have only proxy
			listcase = listproxy

    ## return
	if listcase:
		return listcase
	else:
		return []
