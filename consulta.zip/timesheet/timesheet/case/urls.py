from django.conf.urls import url
from . import views

urlpatterns = [

    # url(r'^/newcase/(?P<parentId>[0-9]+)/$', views.newcase, name='newcase'),
    url(r'^/loadcases$', views.loadcases, name='loadcases'),
    url(r'^/updatecase$', views.update, name='update'),
    url(r'^/newcase/(?P<parentId>[0-9]+)/(?P<idbox>[0-9]+)/$', views.newcase, name='newcase'),
    url(r'^/editcase/(?P<id>[0-9]+)/$', views.editcase, name = 'editcase'),
    url(r'^/deletecase$', views.delete, name='delete'),
    url(r'^/editnamecase$', views.editnamecase, name='editnamecase'),
    url(r'^/getPersonsInCase/(?P<idcase>[0-9]+)/$', views.getPersonsInCase, name='getPersonsInCase'),
    url(r'^/deletepersonofcase/(?P<idcase>[0-9]+)/(?P<idperson>[0-9]+)/$', views.deletepersonofcase, name='deletepersonofcase'),
    url(r'^/clonepersonincase/(?P<iddragperson>[0-9]+)/(?P<idcase>[0-9]+)/$', views.clonepersonincase, name='clonepersonincase'),

]
