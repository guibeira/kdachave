from django import forms
from .models import Case
from box.models import Box, checkhasson
from proxy.models import Proxy, getPersonbyBox
from person.models import Person


class CaseForm(forms.ModelForm):
    #
    # DEFAULT = ()
    # box = forms.ChoiceField(choices=DEFAULT, widget=forms.Select)
    # # boxes = forms.ModelChoiceField(queryset=Box.objects.all())
    #
    # def __init__(self, request, *args, **kwargs):
    #         super(CaseForm, self).__init__(*args, **kwargs)
    #         if request.user:
    #             envio = []
    #             boxes = Box.objects.filter(
    #                 owner=request.user.person)
    #             for box in boxes:
    #                 if box not in envio:
    #                     envio.append(box)
    #             proxys = Proxy.objects.filter(person=request.user.person)
    #             for proxy in proxys:
    #                 if(proxy.box) and (proxy.box not in envio):
    #                     envio.append(proxy.box)
    #             results = checkhasson(envio)
    #             send = []
    #             for result in results:
    #
    #                 send.append((result.pk, result))
    #
    #         else:
    #             send = []
    #         self.fields['box'].choices = send

    class Meta:
        model = Case
        fields = ('name',)


class EditCaseForm(forms.Form):

    DEFAULT = ()
    box = forms.ChoiceField(choices=DEFAULT, widget=forms.Select)
    # boxes = forms.ModelChoiceField(queryset=Box.objects.all())
    owner = forms.ChoiceField(choices=DEFAULT)

    def __init__(self, request, listperson=None, *args, **kwargs):
            super(EditCaseForm, self).__init__(*args, **kwargs)
            if request.user:
                envio = []
                boxes = Box.objects.filter(
                    owner=request.user.person)
                for box in boxes:
                    if box not in envio:
                        envio.append(box)
                proxys = Proxy.objects.filter(person=request.user.person)
                for proxy in proxys:
                    if(proxy.box) and (proxy.box not in envio):
                        envio.append(proxy.box)
                results = checkhasson(envio)
                send = []
                for result in results:

                    send.append((result.pk, result))

            else:
                send = []
            self.fields['box'].choices = send
            if request.user:
                envio = []
                send = []
                if request.user.has_perm('proxy.add_proxy'):
                    retorno = Person.objects.all()
                else:
                    boxes = Box.objects.filter(
                        owner=request.user.person)
                    for box in boxes:
                        if box not in envio:
                            envio.append(box)
                    proxys = Proxy.objects.filter(person=request.user.person)
                    for proxy in proxys:
                        if(proxy.box) and (proxy.box not in envio):
                            envio.append(proxy.box)
                    results = checkhasson(envio)
                    listofperson = []
                    retorno = getPersonbyBox(results, listofperson)
                for person in retorno:
                    # if(person != request.user.person):
                    if listperson:
                        if person not in listperson:
                            send.append((person.pk, person))
                    else:
                        send.append((person.pk, person))
            else:
                send = []
            self.fields['owner'].choices = send

    idsToUpdate = forms.CharField( widget = forms.HiddenInput(), initial=0, label='')
