from django.conf.urls import url
from . import views

urlpatterns = [

    # url(r'^/updateproxy$', views.update, name='update'),
    url(r'^/$', views.listproxy, name='home'),
    url(r'^/newproxy/(?P<idbox>[0-9]+)/$', views.newproxybox, name='newproxy'),
    url(r'^/newproxycase/(?P<idcase>[0-9]+)/$', views.newproxycase, name='newproxycase'),
    url(r'^/getProxiesByBox/(?P<idbox>[0-9]+)/$', views.getProxiesByBox, name='getProxiesByBox'),
    url(r'^/editproxy/(?P<idproxy>[0-9]+)/$', views.editproxy, name='editproxy'),
    url(r'^/editproxycase/(?P<idproxy>[0-9]+)/$', views.editproxycase, name='editproxy'),
    url(r'^/deleteproxy/(?P<idproxy>[0-9]+)/$', views.deleteproxy, name='deleteproxy'),
    url(r'^/info/(?P<idbox>[0-9]+)/$', views.infoproxy, name='info'),

]
