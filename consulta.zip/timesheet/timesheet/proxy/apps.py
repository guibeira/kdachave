from django.apps import AppConfig


class ProxyConfig(AppConfig):
    name = 'proxy'
