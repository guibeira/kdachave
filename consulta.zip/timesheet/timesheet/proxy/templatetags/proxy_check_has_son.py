from django import template
from django.template.defaultfilters import stringfilter
from django.template import Context, Template

register = template.Library()
varhtml = ''
context = {}

def ledic(di):
    global varhtml
    global context
    for c, v in di.items():
        if type(v) == type(list()):
            ## is parent
            varhtml += '<li id="{}"><a href="">{}</a>\n'.format(c.pk,c)
            varhtml += '<ul class="drag">\n'
            for x in range(len(v)):
                if type(v[x]) == type(dict()):
                    ledic(v[x])
                else:
                    ## is son
                    varhtml += '<li id="{}"><a href="">{} - {}</a></li>\n'.format(v[x].pk, v[x],v[x].pk)

            varhtml += '</ul>\n'
            varhtml += '</li>\n'

        else:
            ## is parent
            varhtml += '<li id="{}"><a href="">{} - {}</a>\n'.format(c.pk, c,c.pk)
            varhtml += '<ul class="drag">\n'
            ## is son
            varhtml += '<li id="{}"><a href="">{} - {}</a></li>\n'.format(v.pk, v,v.pk)
            varhtml += '</ul>\n'
            varhtml += '</li>\n'


def callledic(value):
    global varhtml
    global context
    value = [value]
    if(type(value[0]) == type(dict())):
        for key, val in value[0].items():
            ## check if have son
            if type(val) == type(list()):
                ## is parent
                varhtml += '<li id="{}" class="home"><a href="">{}</a></li>\n'.format(key.pk, key)
                for x in range(len(val)):
                    if type(val[x]) == type(dict()):
                        ledic(val[x])
                    else:
                        varhtml += '<li id="{}"><a href="">{} - {}</a></li>\n'.format(val[x].pk, val[x],val[x].pk)
            else:
                varhtml += '<li id="{}"><a href="">{} -  {}</a></li>\n'.format(val.pk, val,val.pk)

        ret = printHtml(varhtml, context)
        varhtml = ''
        return ret
    else:
        varhtml += '<li id="{}" class="home" ><a href="">{}</a></li>\n'.format(value[0].pk, value[0])
        ret = printHtml(varhtml, context)
        varhtml = ''
        return ret



def printHtml(varhtml, context):
    t = Template(varhtml)
    c = Context(context)
    html = t.render(c)
    varhtml = ''
    return html


register.filter('callledic', callledic)
