from django.shortcuts import render, get_object_or_404
from person.models import Person
from box.models import Box
from case.models import Case
from proxy.models import Proxy
from django.contrib.auth.decorators import login_required, permission_required
from datetime import datetime, timezone
from .forms import ProxyForm, EditProxy
from django.http import HttpResponse


now = datetime.now(timezone.utc)


def infoproxy(request, idbox):
	proxys = '';

	proxys = Proxy.objects.get(box__pk=idbox);
	proxys = '{}/{}/{}'.format(proxys.endDate.day, proxys.endDate.month, proxys.endDate.year)

	return HttpResponse(proxys);


@permission_required('proxy.add_person_box')
def newproxybox(request, idbox):

	box = get_object_or_404(Box, pk=idbox)
	toexclude = box.owner
	proxies = Proxy.objects.filter(box=box).filter(startDate__lte=now)
	listperson = []
	for proxy in proxies:
		for p in proxy.person.all():
			if(p not in listperson):
				listperson.append(p)

	if request.method == 'POST':
		form = ProxyForm(request, listperson, toexclude, request.POST)
		obj_parent = get_object_or_404(Box, pk=idbox)
		if form.is_valid():
			proxy = form.save(commit=False)
			proxy.creator = request.user.person
			proxy.box = obj_parent

			proxy.save()
			for p in form.cleaned_data['person']:
				proxy.person.add(p)
			proxy.save()
			return HttpResponse(proxy.box.pk)
		else:
			return render(request, 'modalform.html', {'form': form})
	else:
		form = ProxyForm(request, listperson, toexclude, initial={'startDate': now})

	return render(request, 'modalform.html', {'form': form})


@permission_required('proxy.add_person_case')
def newproxycase(request, idcase):

	case = get_object_or_404(Case, pk=idcase)
	toexclude = case.owner
	proxies = Proxy.objects.filter(case=case).filter(startDate__lte=now)
	listperson = []
	for proxy in proxies:
		for p in proxy.person.all():
			if(p not in listperson):
				listperson.append(p)

	if request.method == 'POST':

		form = ProxyForm(request, listperson, toexclude, request.POST)
		obj_parent = get_object_or_404(Case, pk=idcase)
		if form.is_valid():
			proxy = form.save(commit=False)
			proxy.creator = request.user.person
			proxy.case = obj_parent

			proxy.save()
			for p in form.cleaned_data['person']:
				proxy.person.add(p)
			proxy.save()
			return HttpResponse(proxy.case.pk)
		else:
			return render(request, 'modalform.html', {'form': form})
	else:
		form = ProxyForm(request, listperson, toexclude, initial={'startDate': now})

	return render(request, 'modalform.html', {'form': form})


def checkHasSon(value, user, boxes):

	if(Box.objects.filter(parent=value)):
		d = {value: []}
		for box in Box.objects.filter(parent=value):
			d[value].append(box)
			if d not in boxes:
				boxes.append(d)
			checkHasSon(box,user,boxes)


@login_required
def listproxy(request):
	proxies = []
	listproxy = []
	list_comparator = []
	d = {}
	base_list = []
    ## get logged user
	user = Person.objects.get(user=request.user)
    ## get proxies ralated to logged user
	for proxy in Proxy.objects.filter(person=user).filter(startDate__lte=now).filter(endDate__gte=now):
		if proxy.box:
			d = {proxy.box: []}
			if(Box.objects.filter(parent=proxy.box)):
				for sons in Box.objects.filter(parent=proxy.box):
					d[proxy.box].append(sons)
					if d not in proxies:
						proxies.append(d)
					checkHasSon(sons, user, proxies)
			else:
				proxies.append(d)
				listproxy.append(proxy.box)

    ## check if proxies has value
	if (len(proxies) >= 1):
		# listproxy = []
		## get dict to compare with other elements
		for num in range(len(proxies)):
			comparator = proxies[num]
            ## get key, value of comparator elements
			for k, v in comparator.items():
                ## get element of proxies
				for i in proxies:
                    ##get key, value of proxies item
					for key, val in i.items():
                        ## check if comparator key is diferent of proxies item key
						if (key != k):
                            ## check elements values of proxies
							for x in range(len(v)):
                                ## check if proxie item key is equal of comparator value in element value position
								if key == v[x]:
									comparator[k][x] = i
									listproxy.append(comparator)
						else:
							if i not in list_comparator:
								listproxy.append(i)
								list_comparator.append(i)

	elif len(listproxy) < 1 and len(proxies) <= 1:
		listproxy = proxies

    ## create base list to compare if other proxies are in original list
	def ledic(di):
		for c, v in di.items():
			if type(v) == type(list()):
				if c not in base_list:
					base_list.append(c)
				for x in range(len(v)):
					if type(v[x]) == type(dict()):
						ledic(v[x])
					else:
						if v[x] not in base_list:
							base_list.append(v[x])
			else:
				if c not in base_list:
					base_list.append(c)
				if v not in base_list:
					base_list.append(v)

	if(len(listproxy) > 0):
		if(type(listproxy[0]) == type(dict())):
			temporary_list = []
			for key, val in listproxy[0].items():
				if type(val) == type(list()):
					if key not in base_list:
						base_list.append(key)
					for x in range(len(val)):
						if type(val[x]) == type(dict()):
							ledic(val[x])
						else:
							if val[x] not in base_list:
								base_list.append(val[x])
				else:
					if val not in base_list:
						base_list.append(val)

            ##check if other proxies are in original list
			for x in range(len(list_comparator)):
				val = list(list_comparator[x])
				if val[0] not in base_list:
					temporary_list = list(listproxy[0].values())
					temporary_list[0].append(list_comparator[x])
                    ## prevent the sons of sons that aren't in original list be add one more time
					if type(list(list_comparator[x].values())[0][0]) == type(dict()):
						base_list.append(list(list(list_comparator[x].values())[0][0].keys())[0])

            ## add value of new proxy into original list
			if len(temporary_list) > 0:
				keylistproxy = list(listproxy[0].keys())
				listproxy[0][keylistproxy[0]] = temporary_list[0]

	if listproxy:
		context = {
			'persons': Person.objects.all(),
			'proxies': listproxy[0],
			'cases': Case.objects.all()
		}
	else:
		context = {
			'persons': Person.objects.all(),
			'cases': Case.objects.all()
		}

	return render(request, 'proxy/listproxy.html', context)


@login_required
def getProxiesByBox(request, idbox):
	box = get_object_or_404(Box, pk=idbox)
	proxies = Proxy.objects.filter(box=box).filter(startDate__lte=now).filter(endDate__gte=now)

	context = {
		'proxies' : proxies,
		'idbox' : idbox
	}

	return render(request, 'proxy/detailProxyinBox.html', context)


@permission_required('proxy.edit_person_box')
def editproxy(request, idproxy):
	proxy = get_object_or_404(Proxy, pk=idproxy)
	if request.method == 'POST':
		form = EditProxy( request.POST, instance=proxy)
		if form.is_valid():
			proxy = form.save(commit=False)
			proxy.person.clear()
			proxy.save()
			for p in form.cleaned_data['person']:
				proxy.person.add(p)
			proxy.save()

			return HttpResponse(proxy.box.pk)
	else:
		form = EditProxy(instance=proxy)
	return render(request, 'modalform.html', {'form': form})


@permission_required('proxy.edit_person_case')
def editproxycase(request, idproxy):
	proxy = get_object_or_404(Proxy, pk=idproxy)
	if request.method == 'POST':
		form = EditProxy( request.POST, instance=proxy)
		if form.is_valid():
			proxy = form.save(commit=False)
			proxy.person.clear()
			proxy.save()
			for p in form.cleaned_data['person']:
				proxy.person.add(p)
			proxy.save()

			return HttpResponse(proxy.case.pk)
	else:
		form = EditProxy(instance=proxy)
	return render(request, 'modalform.html', {'form': form})


@login_required
def deleteproxy(request, idproxy):
	proxy = get_object_or_404(Proxy, pk=idproxy)
	proxy.delete()
	return HttpResponse(200)
