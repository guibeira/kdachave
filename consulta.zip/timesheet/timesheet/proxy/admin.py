from django.contrib import admin
from .models import Proxy
# Register your models here.
admin.site.register(Proxy)
