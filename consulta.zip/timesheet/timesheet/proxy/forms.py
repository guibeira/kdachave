from django import forms
from .models import Proxy, getPersonbyBox
from box.models import Box, checkhasson
from person.models import Person


class ProxyForm(forms.ModelForm):

    startDate = forms.DateField(localize=True)
    endDate = forms.DateField(localize=True, required=False)
    DEFAULT = ()
    person = forms.MultipleChoiceField(choices=DEFAULT)

    def __init__(self, request, listperson=None, toexclude=None, *args, **kwargs):
            super(ProxyForm, self).__init__(*args, **kwargs)
            if request.user:
                tosend = []
                send = []
                if request.user.has_perm('proxy.add_proxy'):
                    retorno = Person.objects.all()
                else:
                    boxes = Box.objects.filter(
                        owner=request.user.person)
                    for box in boxes:
                        if box not in tosend:
                            tosend.append(box)
                    proxys = Proxy.objects.filter(person=request.user.person)
                    for proxy in proxys:
                        if(proxy.box) and (proxy.box not in tosend):
                            tosend.append(proxy.box)
                    results = checkhasson(tosend)
                    listofperson = []
                    retorno = getPersonbyBox(results, listofperson)
                for person in retorno:
                    if(person != request.user.person) and (person != toexclude):
                        if listperson:
                            if person not in listperson:
                                send.append((person.pk, person))
                        else:
                            send.append((person.pk, person))
            else:
                send = []
            self.fields['person'].choices = send

    class Meta:
        model = Proxy
        fields = ('person', 'startDate', 'endDate')


class ClonePersonInBoxForm(forms.ModelForm):
    startDate = forms.DateField(localize=True)
    endDate = forms.DateField(localize=True, required=False)

    class Meta:
        model = Proxy
        fields = ('startDate', 'endDate')


class ClonePersonInCaseForm(forms.ModelForm):
    startDate = forms.DateField(localize=True)
    endDate = forms.DateField(localize=True, required=False)

    class Meta:
        model = Proxy
        fields = ('startDate', 'endDate')


class EditProxy(forms.ModelForm):
    startDate = forms.DateField(localize=True)
    endDate = forms.DateField(localize=True, required=False)

    class Meta:
        model = Proxy
        fields = ('person', 'startDate', 'endDate')
