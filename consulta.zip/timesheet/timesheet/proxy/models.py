from django.db import models


class Proxy(models.Model):

    box = models.ForeignKey('box.Box', null=True, blank=True)
    case = models.ForeignKey('case.Case', null=True, blank=True)
    person = models.ManyToManyField('person.Person', related_name='person')
    creator = models.ForeignKey('person.Person', related_name='owner')
    startDate = models.DateTimeField()
    endDate = models.DateTimeField(null=True, blank=True)

    class Meta:
        permissions = (
            ("add_person_box", "Can add Persons in Box"),
            ("add_person_case", "Can add Persons in Cases"),
            ("remove_person_box", "Can remove persons from box"),
            ("remove_person_case", "Can remove persons from cases"),
            ("edit_person_box", "Can edit persons from box"),
            ("edit_person_case", "Can edite persons from cases"),
            )

    def __str__(self):
        return self.creator.name


def getPersonbyBox(boxes, listofperson):
    for box in boxes:
        proxys = Proxy.objects.filter(box=box)
        for proxy in proxys:
            if(proxy.person):
                for person in proxy.person.all():
                    if(person):
                        if person not in listofperson:
                            listofperson.append(person)
    return listofperson
